<?php
session_start();
if(session_destroy()) { // Destroy the session
    header("Location: index.php"); // Redirect to the home page after logout
    exit();
}
?>
