<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'tdl');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['reset_password'])) {
        $email = $_POST['email'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        // Validate password length and complexity
        if (strlen($new_password) < 8 ||
        !preg_match("/[A-Z]/", $new_password) ||
        !preg_match("/[a-z]/", $new_password) ||
        !preg_match("/[0-9]/", $new_password) ) {
        $error = "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number.";
        }
        if ($new_password === $confirm_password) {
            $hashedPassword = password_hash($new_password, PASSWORD_BCRYPT);
    
            $conn->query("UPDATE users SET password='$hashedPassword' WHERE email='$email'");
    
            echo "<script>alert('Password successfully updated! Please log in.');</script>";
            header("Location: login.php");
        } else {
            echo "<script>alert('Passwords do not match. Please try again.');</script>";
        }
    }

    $conn->close();
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#062e3f">
    <meta name="Description" content="Let's do it! - To-Do List WebApp.">
    <title>Reset password Form</title>
    <link rel="stylesheet" href="CSS/main.css" />
    <link rel="stylesheet" href="CSS/login_register.css"> 
    <style>
        .password-policy {
            font-size: 12px;
            color: #d0d0d0;
            margin-top: -10px;
            margin-bottom: 10px;
        }
    </style>
  </head>
  <body>
  <div class="parent">
        <img class="logo" style="height: 20%; width: 10%; position:fixed; padding-top:72px; padding-top:30px;" src="todo.png" alt="Our Logo"/>
  </div>
  <section class="wrapper">
        <div class="form reset">
            <header>Reset Password</header>
            <form method="POST" action="">
                <input type="text" name="email" placeholder="Email address" required />
                <div style="position: relative; display: inline-block;">
                <input type="password" name="new_password" value="" placeholder="8 letters, upper, lower, number" style="width: 365px; padding-right: 30px;"/>
                <span onclick="let a=this.previousElementSibling; (a.type==='password') ? a.setAttribute('type','text') : a.setAttribute('type','password')" style="position: absolute; top: 50%; right: 5px; transform: translateY(-50%); cursor: pointer;">👁</span>
                </div>
                <div style="position: relative; display: inline-block;">
                <input type="password" name="confirm_password" value="" placeholder="8 letters, upper, lower, number" style="width: 365px; padding-right: 30px;"/>
                <span onclick="let a=this.previousElementSibling; (a.type==='password') ? a.setAttribute('type','text') : a.setAttribute('type','password')" style="position: absolute; top: 50%; right: 5px; transform: translateY(-50%); cursor: pointer;">👁</span>
                </div>
                <p class="password-policy">Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number.</p>
                <input type="submit" name="reset_password" value="Reset Password" />
            </form>
        </div>
  </section>
  </bpdy>
  </html>      