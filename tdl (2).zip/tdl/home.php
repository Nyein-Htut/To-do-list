<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Let's Do It - Organize Your Tasks</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="home.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-navbar-dark">
        <a class="navbar-brand" href="#"><img src="todo.png" alt="Logo" class="navbar-logo">Let's Do It</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item px-2"><a class="nav-link" href="https://github.com/Nyein-Htut/To-do-list">Our github</a></li>
                <li class="nav-item px-2"><a class="nav-link" href="login.php">Log in</a></li>
                <li class="nav-item px-2">
                    <!-- Button with link -->
                    <a class="btn btn-primary nav-link text-white" href="login.php">Start for free</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-4">Get it together, without losing your mind!</h1>
                    <p class="lead">Simplify life organizer for both you, provided by group 1.</p>
                    <a href="login.php" class="btn btn-primary btn-lg">Start for free</a>
                </div>
                <div class="col-md-6 text-center">
                    <img src="dashboard.jpg" alt="Dashboard" class="img-fluid rounded shadow">
                </div>
            </div>
        </div>
    </header>

    

    <!-- Footer -->
    <footer class="footer bg-footer-dark py-4">
        <div class="container text-center">
            <p class="mb-0">© 2024 Let's Do It. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap and jQuery Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
