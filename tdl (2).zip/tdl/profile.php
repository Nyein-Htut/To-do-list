<?php 
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['login_user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id'];

// Fetch user details
$sql = "SELECT username, profile_picture, email, reminder_time FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"> 
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="styless.css"> <!-- Add this if you have a separate CSS file for the sidebar -->
</head>
<body>
    <div class="container"> <!-- Add a container to hold both sidebar and profile -->
        <?php include 'sidebar.php'; ?> <!-- Include the sidebar -->
        
        <div class="profile-container">
            <h1>Profile</h1>
            <div class="profile-picture">
                <?php if ($user['profile_picture']): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_picture']) ?: 'default.jpeg'; ?>" alt="Profile Picture" class="profile-picture-img">
                <?php else: ?>
                    <img src="default.jpeg" alt="Default Profile Picture">
                <?php endif; ?>
            </div>
            <div class="profile-details">
                 <?php echo "<p><strong>Username: </strong>" ."<br>".htmlspecialchars($user['username'])."</p>"; 
                 echo "<p><strong>Email: </strong>" ."<br>".htmlspecialchars($user['email']). "</p>";
                 echo "<p><strong>Reminder Time: </strong>" . "<br>".date('h:i A', strtotime($user['reminder_time'])). "</p>";
                 ?>
            </div>
            <div class="profile-actions">
                <a href="edit_profile.php">Edit Profile</a>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
