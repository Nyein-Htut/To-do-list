<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php'; // Make sure the path is correct
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$message = "";
$message_success = "";

include("db_config.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_reg = mysqli_real_escape_string($dbconfig, $_POST['email']);
    $details = mysqli_query($dbconfig, "SELECT username, email FROM users WHERE email='$email_reg'");

    if (mysqli_num_rows($details) > 0) { 
        // Fetch the row data including the username
        $row = mysqli_fetch_assoc($details);
        $username = $row['username']; // Store the username from the database
    
        // Continue with the rest of your logic...
    }
    
    if (mysqli_num_rows($details) > 0) { 
        // If the email is registered
        $message_success = "Successfully emailed! Please check your inbox or spam folder.";

        // Generate a random key
        $key = md5(time() + 123456789 % rand(4000, 55000000));

        // Insert the temporary key into the database
        $sql_insert = mysqli_query($dbconfig, "INSERT INTO forget_password(email, temp_key) VALUES('$email_reg', '$key')");

        // Sending email about the update
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Set the SMTP server to send through
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'manyeinhtuttin@gmail.com'; // SMTP username
            $mail->Password = 'odqrmmkswejowads'; // SMTP password
            $mail->SMTPSecure = 'ssl'; // Enable TLS encryption
            $mail->Port = 465; // TCP port to connect to

            // Recipients
            $mail->setFrom('manyeinhtuttin@gmail.com', 'Lets Do It');
            $mail->addAddress($email_reg); // Add a recipient

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = 'Password Recovery - Lets Do It';
            $mail->Body = "
                            <p>Dear $username,</p>
                            <p>We received a request to reset the password associated with this email address. If you made this request, please click the link below to reset your password:</p>
                            <p><a href='http://localhost/tdl/tdl/forgot_password_reset.php?key=".$key."&email=".$email_reg."'>Reset Your Password</a></p>
                            <p>If clicking the link does not work, please copy and paste the URL into your browser's address bar:</p>
                            <p>http://localhost/tdl/tdl/forgot_password_reset.php?key=".$key."&email=".$email_reg."</p>
                            <p>If you did not request a password reset, please ignore this email. Your password will remain unchanged.</p>
                            <p>Best regards,<br>Lets Do It Team</p>
                        ";
            $mail->send();
        } catch (Exception $e) {
            $message = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $message = "Sorry! No account associated with this email.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/login_register.css">
    <style>
        body {
            background-color: #0d1432; /* Dark blue background */
            color: #fff; /* White text color for contrast */
            padding: 20px;
        }
        .container {
            margin-top: 5%;
        }
        .form-container {
            background-color: #192e54; /* Dark blue form background */
            border-radius: 15px;
            padding: 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        .btn-primary {
            background-color: #0d1031; /* Darker blue for button */
            border-color: #0d1031;
        }
        .btn-primary:hover {
            background-color: #0d1031; /* Even darker blue for hover effect */
            border-color: #0d1031;
        }
        .alert-success {
            background-color: #3d5085; /* Success message background */
            color: #ffffff;
        }
        .alert-danger {
            background-color: #3d5085; /* Error message background */
            color: #ffffff;
        }
        a {
            color: #ffffff; /* Link color */
        }
        a:hover {
            color: #002a3a; /* Hover effect for links */
        }
    </style>
    <title>Forgot Password</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4 form-container">
                <form role="form" method="POST">
                    <div class="form-group">
                        <label for="email" style="margin-bottom: 27px;">Please enter your email to recover password.</label>
                        <input class="form-control" id="email" name="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" placeholder="Email" required />
                    </div>
                    
                    <?php if ($message <> "") {
                        echo"<div class='alert alert-danger' role='alert'>
                        <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>
                        <span class='sr-only'>Error:</span>".$message."</div>";
                    } ?>

                    <?php if ($message_success != ""): ?>
                        <div class="alert alert-success" role="alert"> 
                            <?php echo $message_success; ?>
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary" name="submit" style="display: block; width: 100%; color: #ffffff;">Send Email</button>
                    <br>
                    <center><a href="index.php" style="color: #ffffff;">Back to Login</a></center>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
