    <?php
    session_start();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tdl";


    $conn = new mysqli($servername, $username, $password, $dbname);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if user is logged in
    if (!isset($_SESSION['login_user'])) {
        header("Location: login.php");
        exit();
    }
    // Get the logged-in user's ID from the session
    $user_id = $_SESSION['login_user_id']; // Assuming you store user_id in session on login
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Let's Do It</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
        <link rel="stylesheet" href="styless.css">
        <!-- Linking Google Font Link For Icons -->
        <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
    <body>

    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="index.php"><img src="todo.png" alt="logo" /></a>
            <h2>Let's Do It</h2>
        </div>
        <ul class="sidebar-links">
            <h4>
                <span>Main Menu</span>
                <div class="menu-separator"></div>
            </h4>
            <li>
                <a href="#">
                    <span class="material-symbols-outlined"> task </span>Current tasks</a>
            </li>
            <li>
                <a href="#"><span class="material-symbols-outlined"> check_circle </span>Completed tasks</a>
            </li>
            <li>
                <a href="#"><span class="material-symbols-outlined"> warning </span>Overdue tasks</a>
            </li>
            <h4>
            <span>Category</span>
                <div class="menu-separator"></div>
            </h4>
                    <?php
            // Fetch distinct categories from the categories table
            $sql = "SELECT * FROM categories ORDER BY id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($cat = $result->fetch_assoc()) {
                    $categoryName = htmlspecialchars($cat['name']);
                    $categoryId = $cat['id'];
            
                    switch (strtolower($categoryName)) {
                        case 'work':
                            echo "<li><a href='work.php'><span class='material-symbols-outlined'> work </span>{$categoryName}</a></li>";
                            break;
                        case 'school':
                            echo "<li><a href='school.php'><span class='material-symbols-outlined'> school </span>{$categoryName}</a></li>";
                            break;
                        case 'personal':
                            echo "<li><a href='personal.php'><span class='material-symbols-outlined'> person </span>{$categoryName}</a></li>";
                            break;
                        case 'date':
                            echo "<li><a href='date.php'><span class='material-symbols-outlined'> favorite </span>{$categoryName}</a></li>";
                            break;
                        case 'shopping':
                            echo "<li><a href='shopping.php'><span class='material-symbols-outlined'> shopping_cart </span>{$categoryName}</a></li>";
                            break;
                        case 'other':
                            echo "<li><a href='other.php'><span class='material-symbols-outlined'> more_horiz </span>{$categoryName}</a></li>";
                            break;
                            default:
                            echo "<li><a href='school.php'><span class='material-symbols-outlined'> school </span>{$categoryName}</a></li>";
                            break;
                    }
                }
            } else {
                echo "<li><p>No categories found.</p></li>";
            }
            
            ?>

            <h4>
                <span>Account</span>
                <div class="menu-separator"></div>
            </h4>
            <li>
                <a href="profile.php"><span class="material-symbols-outlined"> account_circle </span>Profile</a>
            </li>
            <li>
                <a href="#"><span class="material-symbols-outlined"> settings </span>Settings</a>
            </li>
            <li>
                <a href="login.php?logout=true"><span class="material-symbols-outlined"> logout </span>Logout</a>
            </li>
        </ul>
        <div class="dev-account">
            <div class="dev-profile">
            <a href="https://github.com/Nyein-Htut/To-do-list"><img src="group.jpg" alt="Group 1" /></a>
                <div class="dev-detail">
                    <h3>Developed by</h3>
                    <h3>Group-1</h3>
                </div>
            </div>
        </div>
    </aside>

    <div class="main" id="mainContent">
        <button class="float-btn" onclick="toggleForm()">+</button>
        
        <div class="task-list-header">
            <h2>Task List</h2>
        </div>
        <div class="task-list">
            <?php
            // Database connection
            $servername = "localhost";
            $username = "root"; 
            $password = "";    
            $dbname = "tdl";    

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch tasks for the logged-in user
            //$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
            $sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, t.repeat_option, c.name as category_name
            FROM tasks t
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE t.user_id = ?";
            
        

            $stmt = $conn->prepare($sql);
        
            $stmt->bind_param("i", $user_id); // Bind user_id if filtering by user
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                    $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                    $taskId = $row["id"];
                    $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase
                
                    // Assign a category class based on the category name
                    $categoryClass = '';
                    switch ($categoryName) {
                        case 'work':
                            $categoryClass = 'task-work';
                            break;
                        case 'school':
                            $categoryClass = 'task-school';
                            break;
                        case 'personal':
                            $categoryClass = 'task-personal';
                            break;
                        case 'date':
                            $categoryClass = 'task-date';
                            break;
                        case 'shopping':
                            $categoryClass = 'task-shopping';
                            break;
                        case 'other':
                            $categoryClass = 'task-other';
                            break;
                        default:
                            $categoryClass = 'task-school';
                            break;
                    }
                
                    echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

                    // Task Name
                    echo "<div class='task-column task-name'>";
                    echo "<h2>" . htmlspecialchars($row["task_name"]) . "</h2>";
                    echo "</div>";

                    // Description with icon
                    echo "<div class='task-column task-description'>";
                    echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                    echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                    echo "</div>";

                    // Category with icon
                    echo "<div class='task-column task-category'>";
                    echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                    echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                    echo "</div>";

                    // Due Date with icon
                    echo "<div class='task-column task-due-date'>";
                    echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                    echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                    echo "</div>";

                    // Due Time with icon
                    echo "<div class='task-column task-due-time'>";
                    echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                    echo "<span>" . htmlspecialchars($dueTime) . "</span>";
                    echo "</div>";

                    // Repeat Option with icon
                    echo "<div class='task-column task-repeat'>";
                    echo "<i class='fas fa-sync-alt'></i>"; // Font Awesome icon for repeat option
                    echo "<span>" . htmlspecialchars($row["repeat_option"]) . "</span>";
                    echo "</div>";

                    // Edit and Delete Buttons
                    echo "<div class='task-column task-actions'>";
                    echo "<button class='edit-btn' onclick=\"openEditForm(" . $row['id'] . ", '" . htmlspecialchars($row['task_name']) . "', '" . htmlspecialchars($row['description']) . "', '" . htmlspecialchars($dueDate) . "', '" . htmlspecialchars($dueTime) . "', '" . htmlspecialchars($row['repeat_option']) . "')\">Edit</button>";
                    echo "<form action='delete_task.php' method='post' style='display:inline;'>";
                    echo "<input type='hidden' name='taskId' value='" . $taskId . "'>";
                    echo "<button type='submit' class='delete-btn'><i class='fas fa-trash'></i> Delete</button>";
                    echo "</form>";
                    echo "</div>";

                    echo "</div>"; // End of task item
                }
            } else {
                echo "<p style='color: #ffffff;'><strong>No tasks found.</strong></p>";
                    
            }

            // Close connection
            $conn->close();
            ?>
        </div>
    </div>

    <!-- Form Overlay -->
    <div id="formOverlay" class="form-overlay">
        <div class="form-container">
            <span class="closebtn" onclick="toggleForm()">&times;</span>
            
            <form id="addItemForm" action="submit_task.php" method="post">
                <input type="hidden" id="taskId" name="taskId" value="">
                
                <div class="input-row">
                <input type="text" id="taskName" name="taskName" placeholder="Task name" required>
                </div>

                <div class="input-row">
                <textarea id="taskDescription" name="taskDescription" placeholder="Description" rows="1"></textarea>
                </div>

                <div class="input-row small-inputs">
                <div class="input-row">
                <div class="icon-input">
                    <label for="dueDate" class="icon"><i class="fa fa-calendar"></i></label>
                    <input type="date" id="dueDate" name="dueDate" placeholder="Due date">
                </div>
                <div class="icon-input">
                    <label for="dueTime" class="icon"><i class="fa fa-clock"></i></label>
                    <input type="time" id="dueTime" name="dueTime" placeholder="Time">
                </div>
                <div class="icon-input">
                    <label for="repeat" class="icon"><i class="fa fa-repeat"></i></label>
                    <select id="repeat" name="repeat">
                        <option value="none">None</option>
                        <option value="daily">Once a Day</option>
                        <option value="weekly">Once a Week</option>
                        <option value="monthly">Once a Month</option>
                    </select>
                </div>
        </div>
            </div>
            <div class="input-row">
                <select id="category" name="category" class="category">
                    <option value="Work">Work</option>
                    <option value="School">School</option>
                    <option value="Personal">Personal</option>
                    <option value="Date">Date</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Other">Other</option>
                </select>
                <button type="submit" id="submitButton">Add task</button>
            </div>
            </form>
        </div>
    </div>

    <!-- Edit Task Form Overlay -->
    <div id="editFormOverlay" class="form-overlay">
        <div class="form-container">
            <span class="closebtn" onclick="toggleEditForm()">&times;</span>
            
            <form id="editTaskForm" action="update_task.php" method="post">
                <input type="hidden" id="editTaskId" name="taskId">

                <div class="input-row">
                <input type="text" id="editTaskName" name="taskName" placeholder="Task name" required>
            </div>

            <!-- Task Description Row -->
            <div class="input-row">
                <textarea id="editTaskDescription" name="taskDescription" placeholder="Description" rows="1"></textarea>
            </div>

            <!-- Due Date, Time, and Repeat Task Row -->
            <div class="input-row small-inputs">
                <div class="icon-input">
                    <label for="editDueDate" class="icon"><i class="fa fa-calendar"></i></label>
                    <input type="date" id="editDueDate" name="dueDate" placeholder="Due date">
                </div>
                <div class="icon-input">
                    <label for="editDueTime" class="icon"><i class="fa fa-clock"></i></label>
                    <input type="time" id="editDueTime" name="dueTime" placeholder="Time">
                </div>
                <div class="icon-input">
                    <label for="editRepeat" class="icon"><i class="fa fa-repeat"></i></label>
                    <select id="editRepeat" name="repeat">
                        <option value="none">None</option>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                </div>
            </div>

            <!-- Category and Update Button Row -->
            <div class="input-row">
            <select id="editCategory" name="category" class="category">
                    <option value="Work">Work</option>
                    <option value="School">School</option>
                    <option value="Personal">Personal</option>
                    <option value="Date">Date</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Other">Other</option>
                </select>
                <button type="submit" id="editSubmitButton">Update Task</button>
            </div>
        </form>
        </div>
    </div>

    <script>
        function toggleForm() {
            var formOverlay = document.getElementById("formOverlay");
            if (formOverlay.style.display === "none" || formOverlay.style.display === "") {
                formOverlay.style.display = "flex";
            } else {
                formOverlay.style.display = "none";
            }
        }

        

    function openEditForm(id, taskName, description, dueDate, dueTime, repeat, category) {
        document.getElementById("editTaskId").value = id;
        document.getElementById("editTaskName").value = taskName;    
        document.getElementById("editTaskDescription").value = description;
        document.getElementById("editDueDate").value = dueDate;
        document.getElementById("editDueTime").value = dueTime;
        document.getElementById("editRepeat").value = repeat;
        document.getElementById("editCategory").value = category;

        
        var editCategorySelect = document.getElementById("editCategory");
        for (var i = 0; i < editCategorySelect.options.length; i++) {
            if (editCategorySelect.options[i].text === category) { // Compare text for categories
                editCategorySelect.selectedIndex = i;
                break;
            }
        }

        var editFormOverlay = document.getElementById("editFormOverlay");
        editFormOverlay.style.display = "flex";
    }


    function toggleEditForm() {
        var editFormOverlay = document.getElementById("editFormOverlay");
        if (editFormOverlay.style.display === "none" || editFormOverlay.style.display === "") {
            editFormOverlay.style.display = "flex";
        } else {
            editFormOverlay.style.display = "none";
        }
    }

    </script>

    </body>
    </html>
