-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2024 at 04:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tdl`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(4, 'Date'),
(6, 'Other'),
(3, 'Personal'),
(2, 'School'),
(5, 'Shopping'),
(1, 'Work');

-- --------------------------------------------------------

--
-- Table structure for table `forget_password`
--

CREATE TABLE `forget_password` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `temp_key` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `forget_password`
--

INSERT INTO `forget_password` (`id`, `email`, `temp_key`, `created`) VALUES
(0, 'hi@gmail.com', '7122a52d44f7667f5dc764a2d491341c', '2024-08-17 07:37:24'),
(0, 'hi@gmail.com', 'c237063ce48177d7f2664dd90f30c8fe', '2024-08-17 07:37:42'),
(0, 'hi@gmail.com', '2897fb8a0a4df48773006add291f82f8', '2024-08-17 07:40:39'),
(0, 'hi@gmail.com', 'bb50799499bfb8d03b69f0ef5134b79a', '2024-08-17 07:43:34'),
(0, 'nyeinirene@gmail.com', '2d78152747b3c971361c2f01ab1809b8', '2024-08-17 07:49:06'),
(0, 'nyeinirene@gmail.com', '8cb6c9540a7aff6aac2d353adf4e46fa', '2024-08-17 07:49:08'),
(0, 'nyeinirene@gmail.com', '86c2c10f119191c9115c2f3085906b58', '2024-08-17 07:50:25'),
(0, 'nyeinirene@gmail.com', '653b1f90c6b075ee86e70379a2405236', '2024-08-17 07:51:41'),
(0, 'nyeinirene@gmail.com', '3a3cf46e2eb56f74f9ea6653ab569439', '2024-08-17 07:59:46'),
(0, 'nyeinirene@gmail.com', '72e77e3130d6215c6716db926b5a3128', '2024-08-17 08:11:40'),
(0, 'nyeinirene@gmail.com', 'ac9260c24ba7f7ccf1c5d880dc33233b', '2024-08-17 08:26:40'),
(0, 'nyeinirene@gmail.com', 'd60d099796c87a8a7c5da5d500ad95cf', '2024-08-17 08:29:12'),
(0, 'nyeinirene@gmail.com', '3bba496482902a72e38c23a01698eff5', '2024-08-17 08:30:17'),
(0, 'nyeinirene@gmail.com', '0d5aa341106283803620c3a21190bd0f', '2024-08-17 08:34:54'),
(0, 'nyeinirene@gmail.com', 'e05e88b4fd465571613b2da29aa5a93b', '2024-08-17 08:35:01'),
(0, 'nyeinirene@gmail.com', '462501fc14cc5355ddd32ceee252f57f', '2024-08-17 08:37:48'),
(0, 'nyeinirene@gmail.com', 'd81e17c232ab9af4560c1d95b03d2716', '2024-08-17 08:42:11'),
(0, 'nht4737@gmail.com', '1349f168dee0d2e3ccd154222c83e08c', '2024-08-17 08:46:15'),
(0, 'nht4737@gmail.com', 'fc66e6da2a9b99ec26d1cc40bbb72a48', '2024-08-17 08:55:18'),
(0, 'nht4737@gmail.com', '76e1fa07faaa7a319e514f9880292b85', '2024-08-17 08:57:03'),
(0, 'nht4737@gmail.com', '260c31a757f2a06dea67888ec9320389', '2024-08-17 08:57:06'),
(0, 'nht4737@gmail.com', '7502354a727db5eef55e3f9db3751b79', '2024-08-17 08:57:22'),
(0, 'nht4737@gmail.com', '4a9b3e442008547409c3407c1eeb6db1', '2024-08-17 08:57:25'),
(0, 'nht4737@gmail.com', '06d8e39ec0bf27445187e946252a0834', '2024-08-17 08:57:31'),
(0, 'nyeinirene@gmail.com', '67ad522050d0f2e8d59da763728adeba', '2024-08-17 09:11:38'),
(0, 'nyeinirene@gmail.com', '1e1420fffd9bfab495eab85e342f249a', '2024-08-17 09:11:48'),
(0, 'nyeinirene@gmail.com', '21c00beff350c97cba9de991e326eb2f', '2024-08-17 09:12:21'),
(0, 'nyeinirene@gmail.com', 'f129fe378cd4ebc6a437e89798425b24', '2024-08-17 09:12:46'),
(0, 'nyeinhtutt@gmail.com', '861b8c32f42b8832777f7f8b96b65cee', '2024-08-19 18:06:01'),
(0, 'nnn@gmail.com', 'c2a117e8fa3a9755c02d84be8830a2e2', '2024-08-19 18:06:21'),
(0, 'nnn@gmail.com', 'd61bbeed73f97c5b5237ac8b81aca5ea', '2024-08-19 18:06:25'),
(0, 'nyeinhtutt@gmail.com', '07ac0cc8ab34ef8a32420f7b768377f6', '2024-08-22 14:57:26'),
(0, 'nyeinhtutt@gmail.com', '288b9ede5e70956716132c341418bc0e', '2024-08-23 08:33:18'),
(0, 'nyeinhtutt@gmail.com', '88f0f3325dc82e412af23c2f870bcaf1', '2024-08-23 08:33:56'),
(0, 'nyeinhtutt@gmail.com', 'f8df61b39517a7cdbebdc834cee70d5d', '2024-08-23 08:34:12'),
(0, 'nyeinhtutt@gmail.com', 'a165a262d9a64f567d8c4bcdedf0ee38', '2024-08-23 09:02:09'),
(0, 'nyeinhtutt@gmail.com', 'e8c322143ed31d4702b469f2d676503d', '2024-08-23 09:03:42'),
(0, 'nyeinhtutt@gmail.com', '14711f131193947152a9fd69cfbb90f8', '2024-08-23 09:04:56'),
(0, 'nyeinhtutt@gmail.com', '83bfec7ff5ad61b745bdc7aa68e01235', '2024-08-23 09:09:13'),
(0, 'nyeinirene@gmail.com', 'ff3d7f77faf7f160281e567e75f0218b', '2024-08-23 09:11:18'),
(0, 'nyeinirene@gmail.com', '673671bf0c0365e79a1dc5cc610eaf3c', '2024-08-23 09:14:43'),
(0, 'nyeinirene@gmail.com', '1fe5f2c6b36188c8f11003f681d67e6f', '2024-08-23 09:22:07');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `due_date` date NOT NULL,
  `due_time` time NOT NULL DEFAULT '00:00:00',
  `repeat_option` enum('none','daily','weekly','monthly') NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `task_name`, `description`, `category_id`, `due_date`, `due_time`, `repeat_option`, `status`) VALUES
(18, 26, 'hh', '', 1, '0000-00-00', '00:00:00', 'none', '1'),
(32, 25, 'completed', '', 1, '0000-00-00', '00:00:00', 'none', 'completed'),
(33, 25, 'lwwww', '', 1, '0000-00-00', '00:00:00', 'none', 'completed'),
(34, 25, 'project', '', 10, '0000-00-00', '00:00:00', 'none', 'completed'),
(35, 25, 'comp', '', 1, '0000-00-00', '00:00:00', 'none', 'completed'),
(40, 24, 'Project', '', 2, '0000-00-00', '00:00:00', 'none', ''),
(41, 24, 'Homework', '', 2, '0000-00-00', '00:00:00', 'none', ''),
(42, 24, 'Skincare', '', 3, '0000-00-00', '00:00:00', 'none', ''),
(43, 24, 'Go out', '', 4, '0000-00-00', '00:00:00', 'none', ''),
(46, 38, 'hello', '', 4, '0000-00-00', '00:00:00', 'none', ''),
(47, 39, 'go out', '', NULL, '0000-00-00', '00:00:00', 'none', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `profile_picture` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `reminder_time` time NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `profile_picture`, `email`, `reminder_time`, `password`) VALUES
(1, 'hnin ei', '', '', '00:00:00', 'f837d4ace7ac322a9d4820af64332842'),
(24, 'nyein', '', 'nyeinirene@gmail.com', '16:00:00', '$2y$10$9WkFOqZEZAmeo4qlXwnzg.4fdtl2OsB5ZtPlZ2DpShRZGZ9aNxhxy'),
(25, 'Hnin Ei Wai Lwin', '', 'lwinwaieihnin@gmail.com', '00:00:00', '$2y$10$FbiiBIOGl/wuSN3LgNtolO7v5brTP32ohwwTYbHuhcglaYGPBz6R2'),
(30, 'hehehehe', '', 'HHHH@gmail.com', '00:00:00', '$2y$10$NEXmEg90iwghTLGgXCc22uc5QnnnTFnRbwYsKAE3j6kOMs2UMad6S'),
(31, 'admin@admin.com', '', 'sdfhks@skdjfhuie.com', '00:00:00', '$2y$10$t1N7NTycf5ih0a6IkAfEReBwg7Zkoi5Kehydscq1fTeHnw37MWE1i'),
(33, 'thoon', '', 'thoon@gmail.com', '00:00:00', '$2y$10$wfavJRBDi20Hb8ZEOy5QR.iVd19ZoakuhoKzM3BCOzQV3iRJDipvu'),
(34, 'lks', '', 'lks@gmail.com', '00:00:00', '$2y$10$7otfc3mbfaHO2dnsJRGVy.s472Hvu/Kk/EXetHHd1UvOB5bMq3xke'),
(35, 'kwangsoo', '', 'leekwangsoo@gmail.com', '00:00:00', '$2y$10$ZOzA/Rgn6hC0vrk.WXi.5uAdbRDPrQTKQFZOsDu12/FBP1.rMQofS'),
(36, 'nixie', '', 'thoosu354@gmail.com', '00:00:00', '$2y$10$KtCQLVOXSUa6kqfSCQCJIe6ZsHOjvGJ9yjq6hFmD7fJyW4cODnEzK'),
(37, 'yellow', 'uploads/Linyi Wallpaper Aesthetic.jpg', 'thoonhsunadi6@gmail.com', '15:00:00', '$2y$10$jo3na1S6jDPZQftddJhGveI1lwdk4wg/yCac/Qda.gRFJ1/GR6U8a'),
(38, 'green', 'uploads/Hakken (1).jpg', 'green@gmail.com', '15:00:00', '$2y$10$2uYE9JR3hWSpAxNQHpIiguXy13u0kldSiSULtnchP1ffrWtyF6BLG'),
(39, 'nadi', '', 'nadi@gmail.com', '00:00:00', '$2y$10$1Iw4l5mIK9avilTLRJ6EsuZobFqKEUEEPNnYMJUnZFhPWP/FTFb46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
