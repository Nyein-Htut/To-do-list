<?php
session_start();
date_default_timezone_set('Asia/Yangon');


    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tdl";


    $conn = new mysqli($servername, $username, $password, $dbname);


    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if user is logged in
    if (!isset($_SESSION['login_user'])) {
        header("Location: login.php");
        exit();
    }
    // Get the logged-in user's ID from the session
    $user_id = $_SESSION['login_user_id'];
     // Assuming you store user_id in session on login
    $currentDateTime = date("Y-m-d H:i:s");
    $todayStart = date("Y-m-d 00:00:00");
    $todayEnd = date("Y-m-d 23:59:59");
    $tomorrowDateTime = date("Y-m-d 00:00:00", strtotime("+1 day"));

    // Check if this is the user's first login
    if (!isset($_SESSION['user_data_lg']) || (isset($_SESSION['user_data_lg']['user_id']) && $_SESSION['user_data_lg']['user_id'] != $user_id)) {
        // Set session data for the first login
        $_SESSION['user_data_lg'] = [
            'user_id' => $user_id,
            'first_login_ss' => true
        ];
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                toggleReminderForm();
            });
        </script>";
    }

     // Update overdue tasks
     $updateOverdueSql = "UPDATE tasks
                          SET status = 'overdue'
                          WHERE due_date != '0000-00-00'
                          AND due_time != '00:00:00'
                          AND CONCAT(due_date, ' ', due_time) < ?
                          AND status != 'completed'
                          AND user_id = ?";

     $updatePendingSql = "UPDATE tasks
                          SET status = 'pending'
                          WHERE (due_date = '0000-00-00'
                          OR CONCAT(due_date, ' ', due_time) > ?)
                          AND status != 'completed'
                          AND user_id = ?";

    $stmt = $conn->prepare($updateOverdueSql);
    $stmt->bind_param("si", $currentDateTime, $user_id);
    $stmt->execute();

    $stmt = $conn->prepare($updatePendingSql);
    $stmt->bind_param("si", $currentDateTime, $user_id);
    $stmt->execute();

    $stmt->close();

    // Overdue Tasks
    $overdueSql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, c.name as category_name, t.status
                FROM tasks t
                LEFT JOIN categories c ON t.category_id = c.id
                WHERE t.user_id = ? AND t.status = 'overdue'";

    // Today's Tasks
    $todaySql = "SELECT t.id, t.task_name, t.description, t.due_date,
                IFNULL(t.due_time, '23:59:59') as due_time,
                c.name as category_name, t.status
        FROM tasks t
        LEFT JOIN categories c ON t.category_id = c.id
        WHERE CONCAT(t.due_date, ' ', t.due_time) BETWEEN ? AND ?
            AND t.status != 'completed' AND t.status != 'overdue'
            AND t.user_id = ?";

    // Upcoming Tasks
    $upcomingSql = "SELECT t.id, t.task_name, t.description, t.due_date,
                    IFNULL(t.due_time, '23:59:59') as due_time,
                    c.name as category_name, t.status
            FROM tasks t
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE CONCAT(t.due_date, ' ', t.due_time) > ?
            AND t.status != 'completed' AND t.status != 'overdue'
            AND t.user_id = ?";

    // Prepare and execute queries
    $stmt = $conn->prepare($overdueSql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $overdueTasks = $stmt->get_result();

    $stmt = $conn->prepare($todaySql);
    $stmt->bind_param("ssi", $todayStart, $todayEnd, $user_id);
    $stmt->execute();
    $todayTasks = $stmt->get_result();

    $stmt = $conn->prepare($upcomingSql);
    $stmt->bind_param("si", $tomorrowDateTime, $user_id);
    $stmt->execute();
    $upcomingTasks = $stmt->get_result();

    // get reminder time
    $reminderSql = "SELECT reminder_time FROM users WHERE id = ?";
    $stmt = $conn->prepare($reminderSql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($saved_reminder_time);
    $stmt->fetch();
    $stmt->close();

?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Let's Do It</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
        <link rel="stylesheet" href="styless.css">
        <link rel="stylesheet" href="set-time.css">
        <!-- Linking Google Font Link For Icons -->
        <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
    <body>

    <?php include('sidebar.php'); ?>

    <div class="main" id="mainContent">
    <button class="float-btn" onclick="toggleForm()">+</button>

    <div class="task-list-header">
        <h2>Task List</h2>
    </div>


    <?php if ($todayTasks->num_rows > 0 || $upcomingTasks->num_rows > 0 || $overdueTasks->num_rows > 0) {
        /* Today Tasks */
        if ($todayTasks->num_rows > 0) {
        echo "<div class='task-category-header'>";
        echo "<h4>Today Tasks</h4>";
        echo "<div class='task-list'>";
            $newTime = '00:00:00';
            $defaultTime = '23:59:59';
            while($row = $todayTasks->fetch_assoc()) {
                $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                if (empty($dueTime) && $dueDate != "No Date") {
                    $dueTime = "23:59:00";
                }
                $taskId = $row["id"];
                $taskStatus = $row["status"];
                $taskDescription = $row["description"];
                $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase

                // Assign a category class based on the category name
                $categoryClass = '';
                switch ($categoryName) {
                    case 'work':
                        $categoryClass = 'task-work';
                        break;
                    case 'school':
                        $categoryClass = 'task-school';
                        break;
                    case 'personal':
                        $categoryClass = 'task-personal';
                        break;
                    case 'date':
                        $categoryClass = 'task-date';
                        break;
                    case 'shopping':
                        $categoryClass = 'task-shopping';
                        break;
                    case 'other':
                        $categoryClass = 'task-other';
                        break;
                    default:
                        $categoryClass = 'task-school';
                        break;
                }

                echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

                // Task Name
                echo "<div class='task-column task-name'>";
                echo "<h3>" . htmlspecialchars($row["task_name"]) . "</h3>";
                echo "</div>";

                // Description with icon
                echo "<div class='task-column task-description'>";
                echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                echo "</div>";

                    // Category with icon
                    echo "<div class='task-column task-category'>";
                    echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                    echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                    echo "</div>";

                    // Due Date with icon
                    echo "<div class='task-column task-due-date'>";
                    echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                    echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                    echo "</div>";

                    // Due Time with icon
                    echo "<div class='task-column task-due-time'>";
                    echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                    if($dueTime=='23:59:00')
                    {echo "<span>" . htmlspecialchars($newTime) . "</span>";}
                    else
                    {echo "<span>" . htmlspecialchars($dueTime) . "</span>";}
                    echo "</div>";

                    // Repeat Option with icon
                    echo "<div class='task-column task-status'>";
                    if($taskStatus=='pending'){
                    echo "<i class='fas fa-hourglass-half'></i>";}
                    elseif($taskStatus=='completed'){
                    echo "<i class='fas fa-check-circle'></i>";}
                    else {
                    echo "<i class='fas fa-exclamation-circle'></i>";}// Font Awesome icon for repeat option
                    echo "<span>" . htmlspecialchars($row["status"]) . "</span>";
                    echo "</div>";
                    // Edit and Delete Buttons
                    echo "<div class='task-column task-actions'>";
                    if ($taskStatus!="completed") {
                        echo "<form action='mark_as_complete.php' method='post' style='display:inline;'>";
                        echo "<input type='hidden' name='taskId' value='" . $taskId . "'>";
                        echo "<button type='submit' class='complete-btn' name='mark_as_completed'><i class='fas fa-check'></i></button>";
                        echo "</form>";
                    }

                    echo "<button class='edit-btn' onclick=\"openEditForm(" . $row['id'] . ", '" . htmlspecialchars($row['task_name']) . "', '" . htmlspecialchars($row['description']) . "', '" . htmlspecialchars($dueDate) . "', '" . htmlspecialchars($dueTime) . "', '" . htmlspecialchars($row['category_name']) . "')\"><i class='fas fa-pencil-alt'></i></button>";
                    // Delete Button with Custom Confirmation
                    echo "<button type='button' class='delete-btn' onclick=\"showConfirmModal(" . $taskId . ")\"><i class='fas fa-trash'></i></button>";
                    echo "</div>";

                    echo "</div>"; // End of task item
                }
                echo "</div>";
                echo "</div>";
            }


    /* <!-- Upcoming Tasks --> */
    if ($upcomingTasks->num_rows > 0) {
        echo "<div class='task-category-header'>";
        echo "<h4>Upcoming Tasks</h4>";
        echo "<div class='task-list'>";
            $newTime = '00:00:00';
            $defaultTime = '23:59:59';
            while($row = $upcomingTasks->fetch_assoc()) {
                $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                if (empty($dueTime) && $dueDate != "No Date") {
                    $dueTime = "23:59:00";
                }
                $taskId = $row["id"];
                $taskStatus = $row["status"];
                $taskDescription = $row["description"];
                $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase

                // Assign a category class based on the category name
                $categoryClass = '';
                switch ($categoryName) {
                    case 'work':
                        $categoryClass = 'task-work';
                        break;
                    case 'school':
                        $categoryClass = 'task-school';
                        break;
                    case 'personal':
                        $categoryClass = 'task-personal';
                        break;
                    case 'date':
                        $categoryClass = 'task-date';
                        break;
                    case 'shopping':
                        $categoryClass = 'task-shopping';
                        break;
                    case 'other':
                        $categoryClass = 'task-other';
                        break;
                    default:
                        $categoryClass = 'task-school';
                        break;
                }

                echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

                // Task Name
                echo "<div class='task-column task-name'>";
                echo "<h3>" . htmlspecialchars($row["task_name"]) . "</h3>";
                echo "</div>";

                // Description with icon
                echo "<div class='task-column task-description'>";
                echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                echo "</div>";

                    // Category with icon
                    echo "<div class='task-column task-category'>";
                    echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                    echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                    echo "</div>";

                    // Due Date with icon
                    echo "<div class='task-column task-due-date'>";
                    echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                    echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                    echo "</div>";

                    // Due Time with icon
                    echo "<div class='task-column task-due-time'>";
                    echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                    if($dueTime=='23:59:00')
                    {echo "<span>" . htmlspecialchars($newTime) . "</span>";}
                    else
                    {echo "<span>" . htmlspecialchars($dueTime) . "</span>";}
                    echo "</div>";

                    // Repeat Option with icon
                    echo "<div class='task-column task-status'>";
                    if($taskStatus=='pending'){
                    echo "<i class='fas fa-hourglass-half'></i>";}
                    elseif($taskStatus=='completed'){
                    echo "<i class='fas fa-check-circle'></i>";}
                    else {
                    echo "<i class='fas fa-exclamation-circle'></i>";}// Font Awesome icon for repeat option
                    echo "<span>" . htmlspecialchars($row["status"]) . "</span>";
                    echo "</div>";
                    // Edit and Delete Buttons
                    echo "<div class='task-column task-actions'>";
                    if ($taskStatus!="completed") {
                        echo "<form action='mark_as_complete.php' method='post' style='display:inline;'>";
                        echo "<input type='hidden' name='taskId' value='" . $taskId . "'>";
                        echo "<button type='submit' class='complete-btn' name='mark_as_completed'><i class='fas fa-check'></i></button>";
                        echo "</form>";
                    }

                    echo "<button class='edit-btn' onclick=\"openEditForm(" . $row['id'] . ", '" . htmlspecialchars($row['task_name']) . "', '" . htmlspecialchars($row['description']) . "', '" . htmlspecialchars($dueDate) . "', '" . htmlspecialchars($dueTime) . "', '" . htmlspecialchars($row['category_name']) . "')\"><i class='fas fa-pencil-alt'></i></button>";
                    // Delete Button with Custom Confirmation
                    echo "<button type='button' class='delete-btn' onclick=\"showConfirmModal(" . $taskId . ")\"><i class='fas fa-trash'></i></button>";
                    echo "</div>";

                    echo "</div>"; // End of task item
                }
                echo "</div>";
                echo "</div>";
            }

    /* <!-- Overdue Tasks --> */
    if ($overdueTasks->num_rows > 0) {
        echo "<div class='task-category-header'>";
        echo "<h4>Overdue Tasks</h4>";
        echo "<div class='task-list'>";
                $newTime = '00:00:00';
                $defaultTime = '23:59:59';
                while($row = $overdueTasks->fetch_assoc()) {
                    $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                    $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                    if (empty($dueTime) && $dueDate != "No Date") {
                        $dueTime = "23:59:00";
                    }
                    $taskId = $row["id"];
                    $taskStatus = $row["status"];
                    $taskDescription = $row["description"];
                    $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase

                    // Assign a category class based on the category name
                    $categoryClass = '';
                    switch ($categoryName) {
                        case 'work':
                            $categoryClass = 'task-work';
                            break;
                        case 'school':
                            $categoryClass = 'task-school';
                            break;
                        case 'personal':
                            $categoryClass = 'task-personal';
                            break;
                        case 'date':
                            $categoryClass = 'task-date';
                            break;
                        case 'shopping':
                            $categoryClass = 'task-shopping';
                            break;
                        case 'other':
                            $categoryClass = 'task-other';
                            break;
                        default:
                            $categoryClass = 'task-school';
                            break;
                    }

                    echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

                    // Task Name
                    echo "<div class='task-column task-name'>";
                    echo "<h3>" . htmlspecialchars($row["task_name"]) . "</h3>";
                    echo "</div>";

                    // Description with icon
                    echo "<div class='task-column task-description'>";
                    echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                    echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                    echo "</div>";

                        // Category with icon
                        echo "<div class='task-column task-category'>";
                        echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                        echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                        echo "</div>";

                        // Due Date with icon
                        echo "<div class='task-column task-due-date'>";
                        echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                        echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                        echo "</div>";

                        // Due Time with icon
                        echo "<div class='task-column task-due-time'>";
                        echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                        if($dueTime=='23:59:00')
                        {echo "<span>" . htmlspecialchars($newTime) . "</span>";}
                        else
                        {echo "<span>" . htmlspecialchars($dueTime) . "</span>";}
                        echo "</div>";

                        // Repeat Option with icon
                        echo "<div class='task-column task-status'>";
                        if($taskStatus=='pending'){
                        echo "<i class='fas fa-hourglass-half'></i>";}
                        elseif($taskStatus=='completed'){
                        echo "<i class='fas fa-check-circle'></i>";}
                        else {
                        echo "<i class='fas fa-exclamation-circle'></i>";}// Font Awesome icon for repeat option
                        echo "<span>" . htmlspecialchars($row["status"]) . "</span>";
                        echo "</div>";
                        // Edit and Delete Buttons
                        echo "<div class='task-column task-actions'>";
                        if ($taskStatus!="completed") {
                            echo "<form action='mark_as_complete.php' method='post' style='display:inline;'>";
                            echo "<input type='hidden' name='taskId' value='" . $taskId . "'>";
                            echo "<button type='submit' class='complete-btn' name='mark_as_completed'><i class='fas fa-check'></i></button>";
                            echo "</form>";
                        }

                        echo "<button class='edit-btn' onclick=\"openEditForm(" . $row['id'] . ", '" . htmlspecialchars($row['task_name']) . "', '" . htmlspecialchars($row['description']) . "', '" . htmlspecialchars($dueDate) . "', '" . htmlspecialchars($dueTime) . "', '" . htmlspecialchars($row['category_name']) . "')\"><i class='fas fa-pencil-alt'></i></button>";
                        // Delete Button with Custom Confirmation
                        echo "<button type='button' class='delete-btn' onclick=\"showConfirmModal(" . $taskId . ")\"><i class='fas fa-trash'></i></button>";
                        echo "</div>";

                        echo "</div>"; // End of task item
                    }
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p style='color: #ffffff; padding:20px;'><strong>No tasks found.</strong></p>";
            }
            ?>
</div>

<!-- Confirmation Modal -->
<div id="confirmModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeConfirmModal()">&times;</span>
        <p>Are you sure you want to delete this task?</p>
        <form id="confirmForm" action="delete_task.php" method="post">
            <input type="hidden" name="taskId" value="<?php echo $taskId; ?>">
            <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
            <input type="hidden" id="confirmTaskId" name="taskId" value="">
            <button type="button" class="confirm-btn" onclick="confirmDeletion()">Delete</button>
            <button type="button" class="cancel-btn" onclick="closeConfirmModal()">Cancel</button>
        </form>
    </div>
</div>

    <!-- reminder form -->
    <div id="reminderFormOverlay" class="form-overlay form-overlay-custom">
        <div class="form-container form-container-custom">
            <span class="closebtn closebtn-custom" onclick="toggleReminderForm()">&times;</span>
            <h2 class="remind-form-header">⏰ Ready to Set a Reminder?</h2>
            <p class="remind-form-subtext">Never miss a task! Pick your perfect reminder time. 🌟</p>

            <form id="timeForm" action="set_time.php" method="post">
                <div class="input-row input-row-custom">
                    <label for="reminderTime"><i class="fa fa-clock"></i></label>
                    <input type="time" id="reminderTime" name="reminderTime" value="<?php echo htmlspecialchars($saved_reminder_time); ?>" required>
                    <button type="submit" id="submitButton">🚀 Set Reminder</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Form Overlay -->
    <div id="formOverlay" class="form-overlay">
        <div class="form-container">
            <span class="closebtn" onclick="toggleForm()">&times;</span>

            <form id="addItemForm" action="submit_task.php" method="post">
                <input type="hidden" id="taskId" name="taskId" value="">

                <div class="input-row">
                <input type="text" id="taskName" name="taskName" placeholder="Task name" required>
                </div>

                <div class="input-row">
                <textarea id="taskDescription" name="taskDescription" placeholder="Description" rows="1"></textarea>
                </div>

                <div class="input-row small-inputs">

                        <div class="icon-input">
                            <label for="dueDate" class="icon"><i class="fa fa-calendar"></i></label>
                            <input type="date" id="dueDate" name="dueDate" placeholder="Due date">
                        </div>
                        <div class="icon-input">
                            <label for="dueTime" class="icon"><i class="fa fa-clock"></i></label>
                            <input type="time" id="dueTime" name="dueTime" placeholder="Time">
                        </div>

                </div>
            <div class="input-row">
                <select id="category" name="category" class="category">
                    <option value="Work">Work</option>
                    <option value="School">School</option>
                    <option value="Personal">Personal</option>
                    <option value="Date">Date</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Other">Other</option>
                </select>
                <button type="submit" id="submitButton">Add task</button>
            </div>
            </form>
        </div>
    </div>

    <!-- Edit Task Form Overlay -->
    <div id="editFormOverlay" class="form-overlay">
        <div class="form-container">
            <span class="closebtn" onclick="toggleEditForm()">&times;</span>

            <form id="editTaskForm" action="update_task.php" method="post">
            <input type="hidden" name="taskId" value="<?php echo $taskId; ?>">
            <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                <input type="hidden" id="editTaskId" name="taskId">

                <div class="input-row">
                <input type="text" id="editTaskName" name="taskName" placeholder="Task name" required>
            </div>

            <!-- Task Description Row -->
            <div class="input-row">
                <textarea id="editTaskDescription" name="taskDescription" placeholder="Description" rows="1"></textarea>
            </div>

            <!-- Due Date, Time, and Repeat Task Row -->
            <div class="input-row small-inputs">
                <div class="icon-input">
                    <label for="editDueDate" class="icon"><i class="fa fa-calendar"></i></label>
                    <input type="date" id="editDueDate" name="dueDate" placeholder="Due date">
                </div>
                <div class="icon-input">
                    <label for="editDueTime" class="icon"><i class="fa fa-clock"></i></label>
                    <input type="time" id="editDueTime" name="dueTime" placeholder="Time">
                </div>
            </div>

            <!-- Category and Update Button Row -->
            <div class="input-row">
            <select id="editCategory" name="category" class="category">
                    <option value="Work">Work</option>
                    <option value="School">School</option>
                    <option value="Personal">Personal</option>
                    <option value="Date">Date</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Other">Other</option>
                </select>
                <button type="submit" id="editSubmitButton">Update Task</button>
            </div>
        </form>
        </div>
    </div>


    <script>
        function toggleReminderForm() {
            var reminderFormOverlay = document.getElementById("reminderFormOverlay");
            if (reminderFormOverlay.style.display === "none" || reminderFormOverlay.style.display === "") {
                reminderFormOverlay.style.display = "flex";
            } else {
                reminderFormOverlay.style.display = "none";
            }
        }

        document.getElementById("timeForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this); // Get form data

            // Send form data via fetch
            fetch("set_time.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Close the modal on success
                    toggleReminderForm();
                }
            })
            .catch(error => console.error('Error:', error));
        });

        function toggleForm() {
            var formOverlay = document.getElementById("formOverlay");
            if (formOverlay.style.display === "none" || formOverlay.style.display === "") {
                formOverlay.style.display = "flex";
            } else {
                formOverlay.style.display = "none";
            }
        }

        document.getElementById('dueDate').addEventListener('input', function() {
    var dueDate = document.getElementById('dueDate').value;
    var dueTime = document.getElementById('dueTime');

    if (dueDate) {
        dueTime.disabled = false;  // Enable due time if due date is filled
    } else {
        dueTime.value = "";  // Clear the due time value if due date is empty
        dueTime.disabled = true;  // Disable due time if due date is not filled
    }

});

document.getElementById('editDueDate').addEventListener('input', function() {
    var editDueDate = document.getElementById('editDueDate').value;
    var editDueTime = document.getElementById('editDueTime');

    if (editDueDate) {
        editDueTime.disabled = false;  // Enable due time if due date is filled
    } else {
        editDueTime.value = "";  // Clear the due time value if due date is empty
        editDueTime.disabled = true;  // Disable due time if due date is not filled
    }
});
document.addEventListener("DOMContentLoaded", function() {
    var dueDate = document.getElementById('dueDate');
    var dueTime = document.getElementById('dueTime');
    var editDueDate = document.getElementById('editDueDate');
    var editDueTime = document.getElementById('editDueTime');

    // Initial check if dueDate is empty
    if (!dueDate.value) {
        dueTime.disabled = true;
    }

    dueDate.addEventListener('input', function() {
        if (dueDate.value) {
            dueTime.disabled = false;
        } else {
            dueTime.value = "";
            dueTime.disabled = true;
        }
    });

    // Initial check for Edit Task form
    if (!editDueDate.value) {
        editDueTime.disabled = true;
    }

    editDueDate.addEventListener('input', function() {
        if (editDueDate.value) {
            editDueTime.disabled = false;
        } else {
            editDueTime.value = "";
            editDueTime.disabled = true;
        }
    });

});



    function openEditForm(id, taskName, description, dueDate, dueTime, category) {
    document.getElementById("editTaskId").value = id;
    document.getElementById("editTaskName").value = taskName;
    document.getElementById("editTaskDescription").value = description;
    document.getElementById("editDueDate").value = dueDate;
    if (dueTime && dueTime.length === 8) {
        dueTime = dueTime.substring(0, 5);
    }
    document.getElementById("editDueTime").value = dueTime;

    document.getElementById("editCategory").value = category;


    var editFormOverlay = document.getElementById("editFormOverlay");
    editFormOverlay.style.display = "flex";

    // Enable or disable the due time field based on due date
    var editDueDate = document.getElementById('editDueDate');
    var editDueTime = document.getElementById('editDueTime');

    if (editDueDate.value) {
        editDueTime.disabled = false;
    } else {
        editDueTime.disabled = true;
    }
}


    function toggleEditForm() {
        var editFormOverlay = document.getElementById("editFormOverlay");
        if (editFormOverlay.style.display === "none" || editFormOverlay.style.display === "") {
            editFormOverlay.style.display = "flex";
        } else {
            editFormOverlay.style.display = "none";
        }
    }

    // Show Confirmation Modal
function showConfirmModal(taskId) {
    document.getElementById("confirmTaskId").value = taskId;
    document.getElementById("confirmModal").style.display = "block";
}

// Close Confirmation Modal
function closeConfirmModal() {
    document.getElementById("confirmModal").style.display = "none";
}

// Confirm Deletion
function confirmDeletion() {
    document.getElementById("confirmForm").submit();
}


    </script>

    </body>
    </html>
    <?php
$stmt->close();
$conn->close();
?>
