<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Optional Side Menu Bar</title>
    <link rel="stylesheet" href="style.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> -->

</head>
<body>

<div class="navbar">
    <!-- Button to open the side menu from the index page -->
    <button class="togglebtn" onclick="toggleNav()">☰ Toggle Side Menu</button>
    <!-- Logout button -->
    <!-- <a href="logout.php" class="loginbtn">Logout</a> -->
    <!-- Manage Account dropdown -->
    <div class="managebtn">
    <a href="login.php?logout=true" class="loginbtn">Logout</a>
    <a href="manage.php"class="loginbtn">Manage Account</a>
        <!-- <div class="dropdown-content">
        <a href="change_password.php">Change Password</a>
            <a href="change_username.php">Change Username</a> -->
            
        <!-- </div> -->
    </div>
</div>

<div id="mySidenav" class="sidenav">
    <!-- Button to close the side menu from inside the sidebar -->
    <button class="togglebtn" onclick="toggleNav()">☰ Toggle Side Menu</button>
    <a href="#home">Home</a>
    <a href="#about">About</a>
    <a href="#services">Services</a>
    <a href="#contact">Contact</a>
</div>

<div class="main" id="mainContent">
<button class="float-btn" onclick="toggleForm()">+</button>
    <!-- Display Tasks -->
     <!-- Display Tasks -->
     <div class="task-list-header">
        <h2>Task List</h2>
    </div>
    <div class="task-list">
        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root"; // Change as needed
        $password = "";     // Change as needed
        $dbname = "tdl";    // Use the existing database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch tasks
        $sql = "SELECT * FROM tasks";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data for each row
            while($row = $result->fetch_assoc()) {
                $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                $dueTime = $row["due_time"] ? $row["due_time"] : "No Date";

                echo "<div class='task-item'>";
                echo "<h3>" . htmlspecialchars($row["task_name"]) . "</h3>";
                echo "<p><strong>Description:</strong> " . htmlspecialchars($row["description"]) . "</p>";
                echo "<p><strong>Due Date:</strong> " . htmlspecialchars($dueDate) . "</p>";
                echo "<p><strong>Due Time:</strong> " . htmlspecialchars($dueTime) . "</p>";
                echo "<p><strong>Repeat:</strong> " . htmlspecialchars($row["repeat_option"]) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No tasks found.</p>";
        }

        // Close connection
        $conn->close();
        ?>
    </div>
</div>
<!-- Form Overlay -->
<!-- Form Overlay -->
<div id="formOverlay" class="form-overlay">
    <div class="form-container">
        <span class="closebtn" onclick="toggleForm()">&times;</span>
        <h2>Add New Task</h2>
        <form id="addItemForm" action="submit_task.php" method="post">
            <label for="taskName">Task Name:</label>
            <input type="text" id="taskName" name="taskName" required>

            <label for="taskDescription">Description:</label>
            <textarea id="taskDescription" name="taskDescription" rows="4"></textarea>

            <label for="dueDate">Due Date:</label>
            <input type="date" id="dueDate" name="dueDate">

            <label for="dueTime">Due Time:</label>
            <input type="time" id="dueTime" name="dueTime">

            <label for="repeat">Repeat:</label>
            <select id="repeat" name="repeat">
                <option value="none">None</option>
                <option value="daily">Once a Day</option>
                <option value="weekly">Once a Week</option>
                <option value="monthly">Once a Month</option>
            </select>

            <button type="submit">Add Task</button>
        </form>
    </div>
</div>


<script>
   function toggleNav() {
    var sidenav = document.getElementById("mySidenav");
    var mainContent = document.getElementById("mainContent");
    var body = document.body; // Reference to the body element

    if (sidenav.style.left === "-250px") {
        openNav(sidenav, mainContent, body);
    } else {
        closeNav(sidenav, mainContent, body);
    }
}

function openNav(sidenav, mainContent, body) {
    sidenav.style.left = "0";
    mainContent.style.marginLeft = "250px";
    body.classList.remove("body-side-menu-closed"); // Add class to adjust header
}

function closeNav(sidenav, mainContent, body) {
    sidenav.style.left = "-250px";
    mainContent.style.marginLeft = "0";
    body.classList.add("body-side-menu-closed"); // Remove class to adjust header
}

    
    function toggleForm() {
        var formOverlay = document.getElementById("formOverlay");
        if (formOverlay.style.display === "none" || formOverlay.style.display === "") {
            formOverlay.style.display = "flex";
        } else {
            formOverlay.style.display = "none";
        }
    }
</script>

</body>
</html>
