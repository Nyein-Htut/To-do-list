<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id'];
$currentDateTime = date("Y-m-d H:i:s");


            // Fetch completed tasks for the logged-in user
            

// Update overdue tasks

// Fetch completed tasks for the logged-in user
/* $sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, t.status, c.name as category_name
        FROM tasks t
        LEFT JOIN categories c ON t.category_id = c.id
        WHERE t.user_id = ? AND t.status = 'overdue'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result(); */

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Let's Do It</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
        <link rel="stylesheet" href="styless.css">
        <!-- Linking Google Font Link For Icons -->
        <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include('sidebar.php'); ?> 
    <<!-- Sidebar included to display on this page -->
    <div class="main" id="mainContent">
        <div class="task-list-header">
            <h3>Overdue Tasks</h3>
        </div>
        <div class="task-list">
            <?php
            $sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, c.name as category_name,t.status
            FROM tasks t
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE t.user_id = ? AND t.status = 'overdue'";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                    $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                    $taskId = $row["id"];
                    $taskDescription = $row["description"];
                    $taskStatus = $row["status"];
                    $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase

                    // Assign a category class based on the category name
                   $categoryClass = '';
                    switch ($categoryName) {
                        case 'work':
                            $categoryClass = 'task-work';
                            break;
                        case 'school':
                            $categoryClass = 'task-school';
                            break;
                        case 'personal':
                            $categoryClass = 'task-personal';
                            break;
                        case 'date':
                            $categoryClass = 'task-date';
                            break;
                        case 'shopping':
                            $categoryClass = 'task-shopping';
                            break;
                        case 'other':
                            $categoryClass = 'task-other';
                            break;
                        default:
                            $categoryClass = 'task-school';
                            break;
                    }
                    echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

                    // Task Name
                    echo "<div class='task-column task-name'>";
                    echo "<h2>" . htmlspecialchars($row["task_name"]) . "</h2>";
                    echo "</div>";

                    // Description with icon
                    echo "<div class='task-column task-description'>";
                    echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                    echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                    echo "</div>";

                    // Category with icon
                    echo "<div class='task-column task-category'>";
                    echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                    echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                    echo "</div>";

                    // Due Date with icon
                    echo "<div class='task-column task-due-date'>";
                    echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                    echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                    echo "</div>";

                    // Due Time with icon
                    echo "<div class='task-column task-due-time'>";
                    echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                    echo "<span>" . htmlspecialchars($dueTime) . "</span>";
                    echo "</div>";

                    // Repeat Option with icon
                    echo "<div class='task-column task-status'>";
                    if($taskStatus=='pending'){
                    echo "<i class='fas fa-hourglass-half'></i>";}
                    elseif($taskStatus=='completed'){
                    echo "<i class='fas fa-check-circle'></i>";}
                    else {
                    echo "<i class='fas fa-exclamation-circle'></i>";}// Font Awesome icon for repeat option
                    echo "<span>" . htmlspecialchars($row["status"]) . "</span>";
                    echo "</div>";
                    // Edit and Delete Buttons
                    echo "<div class='task-column task-actions'>";
                    if ($taskStatus!="completed") {
                        echo "<form action='mark_as_complete.php?return=overdue_tasks.php' method='post' style='display:inline;'>";
                        echo "<input type='hidden' name='taskId' value='" . $taskId . "'>";
                        echo "<button type='submit' class='complete-btn' name='mark_as_completed'><i class='fas fa-check'></i></button>";
                        echo "</form>";
                    }

                    echo "<button class='edit-btn' onclick=\"openEditForm(" . $row['id'] . ", '" . htmlspecialchars($row['task_name']) . "', '" . htmlspecialchars($row['description']) . "', '" . htmlspecialchars($dueDate) . "', '" . htmlspecialchars($dueTime) . "', '" . htmlspecialchars($row['category_name']) . "')\"><i class='fas fa-pencil-alt'></i></button>";                    
                    // Delete Button with Custom Confirmation
                    echo "<button type='button' class='delete-btn' onclick=\"showConfirmModal(" . $taskId . ")\"><i class='fas fa-trash'></i></button>";
                    echo "</div>";
                    echo "</div>"; // End of task item
                }
            } else {
                echo "<p style='color: #ffffff; padding:20px;'><strong>No tasks found.</strong></p>";
                    
            }    
            ?>
        
            
        </div> 
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeConfirmModal()">&times;</span>
            <p>Are you sure you want to delete this task?</p>
            <form id="confirmForm" action="delete_task.php" method="post">
                <input type="hidden" name="taskId" value="<?php echo $taskId; ?>">
                <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                <input type="hidden" id="confirmTaskId" name="taskId" value="">
                <button type="button" class="confirm-btn" onclick="confirmDeletion()">Delete</button>
                <button type="button" class="cancel-btn" onclick="closeConfirmModal()">Cancel</button>
            </form>
        </div>
    </div>

    <div id="editFormOverlay" class="form-overlay">
        <div class="form-container">
            <span class="closebtn" onclick="toggleEditForm()">&times;</span>
            
            <form id="editTaskForm" action="update_task.php" method="post">
            <input type="hidden" name="taskId" value="<?php echo $taskId; ?>">
            <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                <input type="hidden" id="editTaskId" name="taskId">

                <div class="input-row">
                <input type="text" id="editTaskName" name="taskName" placeholder="Task name" required>
            </div>

            <!-- Task Description Row -->
            <div class="input-row">
                <textarea id="editTaskDescription" name="taskDescription" placeholder="Description" rows="1"></textarea>
            </div>

            <!-- Due Date, Time, and Repeat Task Row -->
            <div class="input-row small-inputs">
                <div class="icon-input">
                    <label for="editDueDate" class="icon"><i class="fa fa-calendar"></i></label>
                    <input type="date" id="editDueDate" name="dueDate" placeholder="Due date">
                </div>
                <div class="icon-input">
                    <label for="editDueTime" class="icon"><i class="fa fa-clock"></i></label>
                    <input type="time" id="editDueTime" name="dueTime" placeholder="Time">
                </div>
            </div>

            <!-- Category and Update Button Row -->
            <div class="input-row">
            <select id="editCategory" name="category" class="category">
                    <option value="Work">Work</option>
                    <option value="School">School</option>
                    <option value="Personal">Personal</option>
                    <option value="Date">Date</option>
                    <option value="Shopping">Shopping</option>
                    <option value="Other">Other</option>
                </select>
                <button type="submit" id="editSubmitButton">Update Task</button>
            </div>
        </form>
        </div>
    </div>

<?php 
    $updateOverdueSql = "UPDATE tasks 
    SET status = 'overdue' 
    WHERE due_date != '0000-00-00' 
    AND due_time != '00:00:00'
    AND CONCAT(due_date, ' ', due_time) < ? 
    AND status != 'completed'
    AND user_id = ?";

$updatePendingSql = "UPDATE tasks 
    SET status = 'pending' 
    WHERE (due_date = '0000-00-00' 
    OR CONCAT(due_date, ' ', due_time) > ?) 
    AND status != 'completed'
    AND user_id = ?";
    
    $stmt = $conn->prepare($updateOverdueSql);
    $stmt->bind_param("si", $currentDateTime, $user_id);
    $stmt->execute();
    
    $stmt = $conn->prepare($updatePendingSql);
    $stmt->bind_param("si", $currentDateTime, $user_id);
    $stmt->execute();

?>
   
</body>
<script>
    function openEditForm(id, taskName, description, dueDate, dueTime, category) {
    document.getElementById("editTaskId").value = id;
    document.getElementById("editTaskName").value = taskName;
    document.getElementById("editTaskDescription").value = description;
    document.getElementById("editDueDate").value = dueDate;
    if (dueTime && dueTime.length === 8) {
        dueTime = dueTime.substring(0, 5);
    }
    document.getElementById("editDueTime").value = dueTime;

    // Set the category in the edit form
    var editCategorySelect = document.getElementById("editCategory");
    for (var i = 0; i < editCategorySelect.options.length; i++) {
        if (editCategorySelect.options[i].text === category) { // Compare text for categories
            editCategorySelect.selectedIndex = i;
            break;
        }
    }

    var editFormOverlay = document.getElementById("editFormOverlay");
    editFormOverlay.style.display = "flex";
    
    // Enable or disable the due time field based on due date
    var editDueDate = document.getElementById('editDueDate');
    var editDueTime = document.getElementById('editDueTime');

    if (editDueDate.value) {
        editDueTime.disabled = false;
    } else {
        editDueTime.disabled = true;
    }
}
function toggleEditForm() {
    
    var editFormOverlay = document.getElementById("editFormOverlay");
    if (editFormOverlay.style.display === "none" || editFormOverlay.style.display === "") {
        editFormOverlay.style.display = "flex";
    } else {
        editFormOverlay.style.display = "none";
    }
}

// Show Confirmation Modal
function showConfirmModal(taskId) {
    document.getElementById("confirmTaskId").value = taskId;
    document.getElementById("confirmModal").style.display = "block";
}

// Close Confirmation Modal
function closeConfirmModal() {
    document.getElementById("confirmModal").style.display = "none";
}

// Confirm Deletion
function confirmDeletion() {
    document.getElementById("confirmForm").submit();
}
</script>
</html>
<?php
$stmt->close();
$conn->close();
?>
