<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Change as needed
$password = "";     // Change as needed
$dbname = "tdl";    // Use the existing database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$taskId = $_POST['taskId'];
$taskName = $_POST['taskName'];
$taskDescription = $_POST['taskDescription'];
$dueDate = $_POST['dueDate'];
$dueTime = !empty($_POST['dueTime']) ? $_POST['dueTime'] : '23:59:00';
$repeat = $_POST['repeat'];
$category = $_POST['category'];
// Fetch the category ID from the categories table
if (!empty($category)) {
    $sql = "SELECT id FROM categories WHERE name = ? ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $categoryId = $row['id'];
        $name = htmlspecialchars($row['name']);
        echo $name;
    }
}

// Update task
$sql = "UPDATE tasks SET task_name=?, description=?, due_date=?, due_time=?, repeat_option=?, category_id=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssii", $taskName, $taskDescription, $dueDate, $dueTime, $repeat, $categoryId, $taskId);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    // Redirect to the original page after successful update
    $returnUrl = isset($_POST['returnUrl']) ? $_POST['returnUrl'] : 'Location';
    header("Location: " . $returnUrl);
    exit();
} else {
    $returnUrl = isset($_POST['returnUrl']) ? $_POST['returnUrl'] : 'Location';
    header("Location:". $returnUrl);
}

$stmt->close();
$conn->close();
?>