<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    // Prevent SQL injection
    $user = stripslashes($user);
    $pass = stripslashes($pass);
    $user = $conn->real_escape_string($user);
    $pass = $conn->real_escape_string($pass);

    // Hash the password using MD5
    $hashed_pass = md5($pass);

    // Check if the username already exists
    $sql = "SELECT id FROM users WHERE username = '$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $error = "Username already exists.";
    } else {
        // Insert new user into the database
        $sql = "INSERT INTO users (username, password) VALUES ('$user', '$hashed_pass')";
        if ($conn->query($sql) === TRUE) {
            $success = "Registration successful! You can now login";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="login-container">
    <h2>Register</h2>
    <form action="" method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Register">
    </form>
    <div class="error"><?php echo $error; ?></div>
    <div class="success"><?php echo $success; ?></div>
    <div class="links">
        <a href="login.php" class="back-to-login">Back to Login</a>
    </div>
</div>

</body>
</html>
