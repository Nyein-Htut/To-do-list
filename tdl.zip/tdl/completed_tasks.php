<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id'];

// Fetch completed tasks for the logged-in user
$sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, c.name as category_name
        FROM tasks t
        LEFT JOIN categories c ON t.category_id = c.id
        WHERE t.user_id = ? AND t.status = 'completed'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Let's Do It</title>
    <link rel="stylesheet" href="styless.css">
    <!-- Linking Google Font Link For Icons -->
    <link rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include('sidebar.php'); ?> 
    <<!-- Sidebar included to display on this page -->
    <div class="main" id="mainContent">
        <div class="task-list-header">
            <h2>Completed Tasks</h2>
        </div>
        <div class="task-list">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "tdl";
            
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            
            // Get the logged-in user's ID from the session
            $user_id = $_SESSION['login_user_id'];
            
            // Fetch completed tasks for the logged-in user
            $sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time,t.status, c.name as category_name
                    FROM tasks t
                    LEFT JOIN categories c ON t.category_id = c.id
                    WHERE t.user_id = ? AND t.status = 'completed'";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                    $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                    $taskId = $row["id"];
                    $taskStatus = $row["status"];
                    $taskDescription = $row["description"];
                    $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase

 // Assign a category class based on the category name
$categoryClass = '';
 switch ($categoryName) {
     case 'work':
         $categoryClass = 'task-work';
         break;
     case 'school':
         $categoryClass = 'task-school';
         break;
     case 'personal':
         $categoryClass = 'task-personal';
         break;
     case 'date':
         $categoryClass = 'task-date';
         break;
     case 'shopping':
         $categoryClass = 'task-shopping';
         break;
     case 'other':
         $categoryClass = 'task-other';
         break;
     default:
         $categoryClass = 'task-school';
         break;
 }
                
 echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here

 // Task Name
 echo "<div class='task-column task-name'>";
 echo "<h3>" . htmlspecialchars($row["task_name"]) . "</h3>";
 echo "</div>";

 // Description with icon
 echo "<div class='task-column task-description'>";
 echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
 echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
 echo "</div>";

 // Category with icon
 echo "<div class='task-column task-category'>";
 echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
 echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
 echo "</div>";

 // Due Date with icon
 echo "<div class='task-column task-due-date'>";
 echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
 echo "<span>" . htmlspecialchars($dueDate) . "</span>";
 echo "</div>";

 // Due Time with icon
 echo "<div class='task-column task-due-time'>";
 echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
 echo "<span>" . htmlspecialchars($dueTime) . "</span>";
 echo "</div>";
    
 // Edit and Delete Buttons
 echo "<div class='task-column task-actions'>";

 // Delete Button with Custom Confirmation
 echo "<button type='button' class='delete-btn' onclick=\"showConfirmModal(" . $taskId . ")\"><i class='fas fa-trash'></i></button>";
 echo "</div>";

 echo "</div>"; // End of task item
}
} else {
    echo "<p style='color: #ffffff; padding:20px;'><strong>No tasks found.</strong></p>";
 
}
?>
            
        </div> 
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeConfirmModal()">&times;</span>
            <p>Are you sure you want to delete this task?</p>
            <form id="confirmForm" action="delete_task.php" method="post">
                <input type="hidden" name="taskId" value="<?php echo $taskId; ?>">
                <input type="hidden" name="returnUrl" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                <input type="hidden" id="confirmTaskId" name="taskId" value="">
                <button type="button" class="confirm-btn" onclick="confirmDeletion()">Delete</button>
                <button type="button" class="cancel-btn" onclick="closeConfirmModal()">Cancel</button>
            </form>
        </div>
    </div>
   
</body>
<script>
    // Show Confirmation Modal
function showConfirmModal(taskId) {
    document.getElementById("confirmTaskId").value = taskId;
    document.getElementById("confirmModal").style.display = "block";
}

// Close Confirmation Modal
function closeConfirmModal() {
    document.getElementById("confirmModal").style.display = "none";
}

// Confirm Deletion
function confirmDeletion() {
    document.getElementById("confirmForm").submit();
}
</script>
</html>
<?php
$stmt->close();
$conn->close();
?>
