<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Update with your database password if needed
$dbname = "tdl"; 

// Create connection
$dbconfig = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($dbconfig->connect_error) {
    die("Connection failed: " . $dbconfig->connect_error);
}
?>
