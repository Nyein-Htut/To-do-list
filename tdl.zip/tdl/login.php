<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'tdl');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error variable
$error = '';

// Handle login
if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    // Check for user in the database
    $result = $conn->query("SELECT * FROM users WHERE email='$email'");

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {
            $user_id = $row['id'];
            $username = $row['username'];

            // Store session variables
            $_SESSION['login_user'] = $username;
            $_SESSION['login_user_id'] = $user_id;

            // create a file
            $file = $user_id.'.txt';

            // store the user ID
            file_put_contents($file, $user_id);

            header("Location: index.php"); // Redirect to index page after successful login
            exit();
        } else {
            $error = "Your email or password is invalid";
        }
    } else {
        $error = "Your email or password is invalid";
    }
}

// Handle registration
if (isset($_POST['register'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    // Check if username already exists
    $usernameCheck = $conn->query("SELECT * FROM users WHERE username='$username'");
    if ($usernameCheck->num_rows > 0) {
        $error = "Username already exists";
    }

    // Check if email already exists
    $emailCheck = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($emailCheck->num_rows > 0) {
        $error = "Email already exists";
    }

    // Validate password length and complexity
    if (strlen($password) < 8 ||
        !preg_match("/[A-Z]/", $password) ||
        !preg_match("/[a-z]/", $password) ||
        !preg_match("/[0-9]/", $password) ) {
        $error = "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number.";
    }

    // If there are no errors, proceed with registration
    if (empty($error)) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format.";
            exit();
        }

        // Encrypt the password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Prepare and execute the insert query
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            $_SESSION['user'] = $email;
            header("Location: login.php?signup=success");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="theme-color" content="#062e3f">
    <meta name="Description" content="Let's do it! - To-Do List WebApp.">
    <title>Login & Signup Form</title>
    <link rel="stylesheet" href="CSS/main.css" />
    <link rel="stylesheet" href="CSS/login_register.css">
    <style>
        /* Notification Styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #3d5085;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            opacity: 0;
            transform: translateY(-20px);
            transition: opacity 0.5s ease, transform 0.5s ease;
            z-index: 1000;
        }
        .notification.error {
            background: #f44336; /* Red */
        }
        .notification.show {
            opacity: 1;
            transform: translateY(0);
        }

        .password-policy {
            font-size: 11px;
            color: #d0d0d0;
            margin-top: -10px;
            margin-bottom: 0px;
        }
    </style>
</head>
<body>



    <section class="wrapper">
        <div class="form signup">
            <header>Signup</header>
            <form method="POST" action="">
                <input type="text" name="username" placeholder="Username" required />
                <input type="email" name="email" placeholder="Email address" required />
                <div style="position: relative; display: inline-block;">
                <input type="password" name="password" value="" placeholder="8 letters, upper, lower, number" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[A-Za-z\d@$!%*?&]{8,}" style="width: 365px; padding-right: 30px;"/>
                <span onclick="let a=this.previousElementSibling; (a.type==='password') ? a.setAttribute('type','text') : a.setAttribute('type','password')" style="position: absolute; top: 50%; right: 5px; transform: translateY(-50%); cursor: pointer;">👁</span>
                </div>
                <p class="password-policy">Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number.</p><div class="checkbox">
                    <input type="checkbox" id="signupCheck" required/>
                    <label for="signupCheck">I accept all terms & conditions</label>
                </div>
                <button type="submit" name="register" value="Signup">Signup</button>

            </form>
        </div>

        <div class="form login">
            <header>Login</header>
            <form method="POST" action="">
                <input type="email" name="email" placeholder="Email address" required />
                <div style="position: relative; display: inline-block;">
                <input type="password" name="password" value="" placeholder="8 letters, upper, lower, number" style="width: 365px; padding-right: 30px;"/>
                <span onclick="let a=this.previousElementSibling; (a.type==='password') ? a.setAttribute('type','text') : a.setAttribute('type','password')" style="position: absolute; top: 50%; right: 5px; transform: translateY(-50%); cursor: pointer;">👁</span>
                </div>
                <a href="forgot_password.php">Forgot password?</a>
                <input type="submit" name="login" value="Login" />
            </form>
        </div>

        <?php if (isset($_GET['reset'])): ?>
        <div class="form reset">
            <header>Reset Password</header>
            <form method="POST" action="">
                <input type="text" name="email" placeholder="Email address" required />
                <input type="password" name="new_password" placeholder="New Password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}" title="Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character." />
                <input type="password" name="confirm_password" placeholder="Confirm Password" required />
                <input type="submit" name="reset_password" value="Reset Password" />
            </form>
        </div>
        <?php endif; ?>

        <!-- Error Notification -->
        <?php if (!empty($error)): ?>
        <div class="notification error show" id="errorNotification">
            <?php echo $error; ?>
        </div>
        <script>
            setTimeout(() => {
                document.getElementById('errorNotification').classList.remove('show');
            }, 4000); // Hide after 4 seconds
        </script>
        <?php endif; ?>

        <div class="notification" id="signupNotification">
            Successfully signed up! Please log in to continue!
        </div>

        <script>
            const wrapper = document.querySelector(".wrapper"),
                signupHeader = document.querySelector(".signup header"),
                loginHeader = document.querySelector(".login header");

            loginHeader.addEventListener("click", () => {
                wrapper.classList.add("active");
            });
            signupHeader.addEventListener("click", () => {
                wrapper.classList.remove("active");
            });

            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('signup') && urlParams.get('signup') === 'success') {
                const notification = document.getElementById('signupNotification');
                notification.classList.add('show');
                setTimeout(() => {
                    notification.classList.remove('show');
                }, 4000); // Hide after 4 seconds
            }
        </script>
    </section>



</body>
</html>
