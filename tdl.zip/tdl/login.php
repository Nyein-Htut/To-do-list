<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    // Prevent SQL injection
    $user = stripslashes($user);
    $pass = stripslashes($pass);
    $user = $conn->real_escape_string($user);
    $pass = $conn->real_escape_string($pass);

    // Hash the password using MD5
    $hashed_pass = md5($pass);

    // Query to check user credentials
    $sql = "SELECT id FROM users WHERE username = '$user' AND password = '$hashed_pass'";
    
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Store session variables
        $_SESSION['login_user'] = $user;
        header("location: index.php"); // Redirect to index page after successful login
        exit();
    } else {
        $error = "Your Login Name or Password is invalid";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <form action="" method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Login">
    </form>
    <div class="error"><?php echo $error; ?></div>
    <div style="text-align: center; margin-top: 10px;">
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>

</body>
</html>
