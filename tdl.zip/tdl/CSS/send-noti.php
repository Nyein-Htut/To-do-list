<?php

include 'db_config.php';

use Google\Auth\Credentials\ServiceAccountCredentials;
use Google\Auth\HttpHandler\Guzzle6HttpHandler;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;

require 'vendor/autoload.php';

date_default_timezone_set('Asia/Yangon');

$directory = 'C:/xampp/htdocs/tdl/';
// chdir($directory); // Change to the correct directory
$files = glob($directory . '*.txt'); // Ensure the path includes a trailing slash

// Check if any .txt file is found
if (!empty($files)) {
  // Take the first .txt file found
  $file = $files[0];

  // Get the contents of the file
  $user_id = file_get_contents($file);
  // $user_id = 40;
  // Output the file contents (for testing purposes)
  echo $user_id;
} else {
  // Handle the case where no .txt file is found
  echo "No .txt file found.";
}

if ($user_id ) {
  $getTasksQuery = "SELECT * FROM tasks WHERE user_id = ?";
  $stmt = $dbconfig->prepare($getTasksQuery);
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
    $getReminderTimeQuery = "SELECT reminder_time FROM users WHERE id = ?";
    $stmt = $dbconfig->prepare($getReminderTimeQuery);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $reminder_time = $user['reminder_time'];
    $reminder_time = substr($reminder_time, 0, 5);
    $current_time = date('H:i');
    echo $reminder_time;
    echo $current_time;

    if ($reminder_time === $current_time) {
      // Create a Guzzle HTTP client with SSL verification disabled
      $guzzleClient = new Client(['verify' => false]);

      // Use Guzzle6HttpHandler to disable SSL verification
      $httpHandler = new Guzzle6HttpHandler($guzzleClient);

      // Create the credentials object
      $credential = new ServiceAccountCredentials(
          "https://www.googleapis.com/auth/firebase.messaging",
          json_decode(file_get_contents("C:/xampp/htdocs/tdl/pvKey.json"), true)
      );

      // Fetch the access token using the custom HTTP handler
      $token = $credential->fetchAuthToken($httpHandler);

      $ch = curl_init("https://fcm.googleapis.com/v1/projects/tdl-1-b52d4/messages:send");

      curl_setopt($ch, CURLOPT_HTTPHEADER, [
          'Content-Type: application/json',
          'Authorization: Bearer ' . $token['access_token']
      ]);

      curl_setopt($ch, CURLOPT_POSTFIELDS, '{
          "message": {
            "token": "dljJvwaqiXDbJFb0Gu7AlN:APA91bHMP0zLYHsYRJKzra9k34S6v2UJDim_xeMlLpfKB0a_1uvQcN1Qat-E_pPIIKYlehxr07hfLhMeyttVQE_qtA5tagx7KqD3XHIo_ck9GFBbEjiDyU9iA6OJ5hwGx4JMy_-Tj6Ea",
            "notification": {
              "title": "Tasks Awaiting You!",
              "body": "A productive day ahead! Dive into your tasks now."
            },
            "webpush": {
              "fcm_options": {
                "link": "http://localhost/tdl"
              }
            }
          }
        }');

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "post");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Capture the response as a string
        curl_setopt($ch, CURLOPT_VERBOSE, true); // Enable verbose output for debugging
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

      $response = curl_exec($ch);

      curl_close($ch);

      echo $response;
    }
  }
  } else {
    // No tasks found for the current user
    echo "No tasks found for the current user.";
  }
?>
