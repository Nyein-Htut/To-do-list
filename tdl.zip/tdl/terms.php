<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Let's Do It - Terms and Conditions</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="home.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-navbar-dark">
        <a class="navbar-brand" href="#"><img src="todo.png" alt="Logo" class="navbar-logo">Let's Do It</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item px-2"><a class="nav-link" href="https://github.com/Nyein-Htut/To-do-list">Our GitHub</a></li>
                <li class="nav-item px-2"><a class="nav-link" href="login.php">Back to Log In</a></li>
            </ul>
        </div>
    </nav>

    <!-- Terms and Conditions Section -->
    <section class="terms-section py-5">
        <div class="container">
            <h1 class="display-4">Terms and Conditions</h1>
            <p>Welcome to Let's Do It! By using our to-do list web application, you agree to comply with and be bound by the following terms and conditions of use. Please review them carefully.</p>
            
            <h2>1. Acceptance of Terms</h2>
            <p>By accessing and using the Let's Do It website and services, you accept and agree to be bound by these terms. If you do not agree, you should not use the service.</p>
            
            <h2>2. Account Registration</h2>
            <p>To access certain features of the service, you must register an account. You are responsible for maintaining the confidentiality of your account and password and for any activity that occurs under your account.</p>
            
            <h2>3. User Responsibilities</h2>
            <p>You agree not to use the service for any unlawful or prohibited activities, including, but not limited to, activities that:</p>
            <ul>
                <li>Infringe on the intellectual property rights of others.</li>
                <li>Contain harmful or illegal content.</li>
                <li>Disrupt or attempt to disrupt the service’s functionality.</li>
            </ul>
            
            <h2>4. Content Ownership</h2>
            <p>All content, including tasks and data submitted by users, remains the property of the user. However, by using the service, you grant Let's Do It permission to store and manage the content as necessary to provide the service.</p>
            
            <h2>5. Termination</h2>
            <p>We reserve the right to suspend or terminate your account if you violate these terms or if your actions may harm the integrity or operation of the service.</p>
            
            <h2>6. Limitation of Liability</h2>
            <p>Let's Do It is not liable for any direct, indirect, incidental, or consequential damages arising from your use of the service, including data loss or service disruptions.</p>
            
            <h2>7. Modifications to the Service</h2>
            <p>We reserve the right to modify, suspend, or discontinue any part of the service at any time without notice or liability to users.</p>
            
            <h2>8. Privacy</h2>
            <p>Your use of the service is also governed by our Privacy Policy, which explains how we collect, use, and protect your personal data.</p>
            
            <h2>9. Governing Law</h2>
            <p>These terms are governed by and construed in accordance with the laws of [Your Country]. Any disputes arising under these terms shall be subject to the exclusive jurisdiction of the courts in [Your City].</p>

            <h2>10. Contact Information</h2>
            <p>If you have any questions about these terms, please contact us..</p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer bg-footer-dark py-4">
        <div class="container text-center">
            <p class="mb-0">© 2024 Let's Do It. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap and jQuery Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
