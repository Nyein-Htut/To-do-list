<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Check if task ID is provided
if (isset($_POST['taskId'])) {
    $taskId = intval($_POST['taskId']);
    $user_id = $_SESSION['login_user_id']; // Assuming you store user_id in session on login

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tdl";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Delete task
    $sql = "DELETE FROM tasks WHERE id=? AND user_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $taskId, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Redirect to the original page after successful update
        $returnUrl = isset($_POST['returnUrl']) ? $_POST['returnUrl'] : 'index.php';
        header("Location: " . $returnUrl);
        exit();
    } else {
        $returnUrl = isset($_POST['returnUrl']) ? $_POST['returnUrl'] : 'index.php';
        header("Location:". $returnUrl);
    }
}
$stmt->close();
$conn->close();
?>
