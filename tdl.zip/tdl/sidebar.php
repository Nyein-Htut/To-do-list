<?php include 'db_config.php'; ?>
<aside class="sidebar">
        <div class="sidebar-header">
            <a href="index.php"><img src="todo.png" alt="logo" /></a>
            <h2>Let's Do It</h2>
        </div>
        <ul class="sidebar-links">
            <h4>
                <span>Main Menu</span>
                <div class="menu-separator"></div>
            </h4>
            <li>
                <a href="current_tasks.php" class="current-tasks"><span class="material-symbols-outlined"> task </span>Current tasks</a>
            </li>
            <li>
                <a href="completed_tasks.php" class="completed-tasks"><span class="material-symbols-outlined"> check_circle </span>Completed tasks</a>
            </li>
            <li>
                <a href="overdue_tasks.php" class="overdue-tasks"><span class="material-symbols-outlined"> warning </span>Overdue tasks</a>
            </li>

            <h4>
            <span>Category</span>
                <div class="menu-separator"></div>
            </h4>
                    <?php
            // Fetch distinct categories from the categories table
            $sql = "SELECT * FROM categories ORDER BY id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($cat = $result->fetch_assoc()) {
                    $categoryName = htmlspecialchars($cat['name']);
                    $categoryId = $cat['id'];
            
                    switch (strtolower($categoryName)) {
                        case 'work':
                            echo "<li><a href='work.php' class='work-category'><span class='material-symbols-outlined'> work </span>{$categoryName}</a></li>";
                            break;
                        case 'school':
                            echo "<li><a href='school.php' class='school-category'><span class='material-symbols-outlined'> school </span>{$categoryName}</a></li>";
                            break;
                        case 'personal':
                            echo "<li><a href='personal.php' class='personal-category'><span class='material-symbols-outlined'> person </span>{$categoryName}</a></li>";
                            break;
                        case 'date':
                            echo "<li><a href='date.php' class='date-category'><span class='material-symbols-outlined'> favorite </span>{$categoryName}</a></li>";
                            break;
                        case 'shopping':
                            echo "<li><a href='shopping.php' class='shopping-category'><span class='material-symbols-outlined'> shopping_cart </span>{$categoryName}</a></li>";
                            break;
                        case 'other':
                            echo "<li><a href='other.php' class='other-category'><span class='material-symbols-outlined'> more_horiz </span>{$categoryName}</a></li>";
                            break;
                        default:
                            echo "<li><a href='school.php' class='school-category'><span class='material-symbols-outlined'> school </span>{$categoryName}</a></li>";
                            break;                    
                    }
                }
            } else {
                echo "<li><p>No categories found.</p></li>";
            }
            
            ?>

            <h4>
                <span>Account</span>
                <div class="menu-separator"></div>
            </h4>
            <li>
                <a href="profile.php" class="profile"><span class="material-symbols-outlined"> account_circle </span>Profile</a>
            </li>
            <li>
                <a href="login.php?logout=true" class="logout"><span class="material-symbols-outlined"> logout </span>Logout</a>
            </li>
            <li>
                <a href="home.php" class="home"><span class="material-symbols-outlined"> home </span>Back to home</a>
            </li>

        </ul>
        <div class="dev-account">
            <div class="dev-profile">
            <img src="group.jpg" alt="Group 1" />
                <div class="dev-detail">
                    <h3>Developed by</h3>
                    <h3>Group-1</h3>
                </div>
            </div>
        </div>
    </aside>
