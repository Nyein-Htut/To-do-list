<?php
session_start();
include 'db_config.php'; 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['login_user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id'];

// Fetch user details
$sql = "SELECT username, profile_picture, email, reminder_time FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Initialize error variable
$error = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $reminder_time = $conn->real_escape_string($_POST['reminder_time']);

    // Check for username duplication
    $usernameCheck = $conn->query("SELECT * FROM users WHERE username='$username' AND id != $user_id");
    if ($usernameCheck->num_rows > 0) {
        $error = "Username already exists";
    }

    // Check for email duplication
    $emailCheck = $conn->query("SELECT * FROM users WHERE email='$email' AND id != $user_id");
    if ($emailCheck->num_rows > 0) {
        $error = "Email already exists";
    }

    // If no errors, update user details
    if (empty($error)) {
        // Handle file upload
        if (!empty($_FILES['profile_picture']['name'])) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
            move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);
        } else {
            $target_file = $user['profile_picture']; // Use existing picture if no new upload
        }

        // Update user details
        $sql = "UPDATE users SET username = ?, email = ?, reminder_time = ?, profile_picture = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $username, $email, $reminder_time, $target_file, $user_id);

        if ($stmt->execute()) {
            // Redirect to the profile page
            header("Location: profile.php");
            exit();
        } else {
            $error = "Error updating record: " . $stmt->error;
        }
    }
}

// Close connection
/*$conn->close();*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"> 
    <link rel="stylesheet" href="edit_profile.css">
    <link rel="stylesheet" href="styless.css">
    <style>
        /* Notification Styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #3d5085;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            opacity: 0;
            transform: translateY(-20px);
            transition: opacity 0.5s ease, transform 0.5s ease;
            z-index: 1000;
        }
        .notification.error {
            background: #f44336; /* Red */
        }
        .notification.show {
            opacity: 1;
            transform: translateY(0);
        }

    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <div class="profile-container">
        <h1>Edit Profile</h1>
        <form action="edit_profile.php" method="POST" enctype="multipart/form-data">
            <div class="profile-picture">
                <!-- Display the current profile picture or a default image if none exists -->
                <img id="profilePicturePreview" src="<?php echo !empty($user['profile_picture']) && file_exists($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'default.jpeg'; ?>" alt="Profile Picture" class="profile-picture-img">
                <input type="file" name="profile_picture" id="profilePictureInput">
            </div>
            <div class="profile-details">
                <label for="username"><strong>Username:</strong></label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                
                <label for="email"><strong>Email:</strong></label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                
                <label for="reminder_time"><strong>Reminder Time:</strong></label>
                <input type="time" id="reminder_time" name="reminder_time" pattern="^([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$" placeholder="HH:MM:SS" value="<?php echo htmlspecialchars($user['reminder_time']); ?>" required>
            </div>  
            <div class="profile-actions">
                <button type="submit">Save Changes</button>
                <a href="profile.php">Cancel</a>
            </div>
        </form>

        <script>document.getElementById('profilePictureInput').addEventListener('change', function(event) {
                const file = event.target.files[0]; // Get the selected file
                if (file) {
                    const reader = new FileReader(); // Create a FileReader to read the file
                    reader.onload = function(e) {
                        document.getElementById('profilePicturePreview').src = e.target.result; // Set the image src to the file content
                    };
                    reader.readAsDataURL(file); // Read the file as a data URL
                }
            });
</script>
        <?php if (!empty($error)): ?>
        <div class="notification error show" id="errorNotification">
            <?php echo $error; ?>
        </div>
        <script>
            setTimeout(() => {
                document.getElementById('errorNotification').classList.remove('show');
            }, 4000); // Hide after 4 seconds

        </script>
        <?php endif; ?>
    </div>
</body>
</html>
