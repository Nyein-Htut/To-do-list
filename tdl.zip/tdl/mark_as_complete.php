<?php
session_start();
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the form was submitted
if (isset($_POST['mark_as_completed'])) {
    // Get the task ID from the form
    $taskId = $_POST['taskId'];
    // Get the logged-in user's ID from the session
    $userId = $_SESSION['login_user_id'];

    // Update the task's status to 'completed' for the logged-in user
    $sql = "UPDATE tasks SET status='completed' WHERE id=? AND user_id=?  ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $taskId, $userId);
    $stmt->execute();

    // Check if the task was successfully updated
    if (isset($_GET['return']) && !empty($_GET['return'])) {
        $returnLocation = $_GET['return'];
    } else {
        // Default redirection if no return location is specified
        $returnLocation = "index.php";
    }

    // Redirect back to the task list
    header("Location: $returnLocation");
    exit();
} else {
    // Redirect if no task ID is provided
    header("Location: index.php");
    exit();
}
    /* // Redirect back to the task list page with feedback
    header("Location: index.php");
    exit();
} else {
    
    // If the form was not submitted, redirect to the task list page
    header("Location: index.php");
    exit(); */

?>
