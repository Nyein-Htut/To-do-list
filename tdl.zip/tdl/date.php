<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['login_user_id'];

$CategoryQuery = "SELECT id, name FROM categories WHERE name = 'date'";
$CategoryResult = $conn->query($CategoryQuery);

if ($CategoryResult->num_rows > 0) {
    $CategoryRow = $CategoryResult->fetch_assoc();
    $CategoryId = $CategoryRow['id'];
    $CategoryName = htmlspecialchars($CategoryRow['name']);  // Get category name from SQL result
} else {
    echo "Category not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Let's Do It</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="styless.css">
    <!-- Linking Google Font Link For Icons -->
    <link rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body>

<?php include('sidebar.php')?>

<div class="main" id="mainContent">
    
    <div class="task-list-header">
        <h2><?php echo $CategoryName?> Task List</h2>
    </div>
    <div class="task-list">
        <?php
        $user_id = $_SESSION['login_user_id'];
        
        $sql = "SELECT t.id, t.task_name, t.description, t.due_date, t.due_time, t.status, c.name as category_name
                FROM tasks t
                LEFT JOIN categories c ON t.category_id = c.id
                WHERE t.user_id = ? AND category_id = 4";
                
                $stmt = $conn->prepare($sql);
               
                $stmt->bind_param("i", $user_id); // Bind user_id if filtering by user
                $stmt->execute();
                $result = $stmt->get_result();
        
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $dueDate = $row["due_date"] ? $row["due_date"] : "No Date";
                        $dueTime = $row["due_time"] ? $row["due_time"] : "No Time";
                        $taskId = $row["id"];
                        $taskStatus = $row["status"];
                        $categoryName = strtolower($row["category_name"]); // Get category name and convert to lowercase
                    
                        // Assign a category class based on the category name
                        $categoryClass = '';
                        switch ($categoryName) {
                            case 'work':
                                $categoryClass = 'task-work';
                                break;
                            case 'school':
                                $categoryClass = 'task-school';
                                break;
                            case 'personal':
                                $categoryClass = 'task-personal';
                                break;
                            case 'date':
                                $categoryClass = 'task-date';
                                break;
                            case 'shopping':
                                $categoryClass = 'task-shopping';
                                break;
                            case 'other':
                                $categoryClass = 'task-other';
                                break;
                            default:
                                $categoryClass = 'task-school';
                                break;
                        }
                    
                        echo "<div class='task-item $categoryClass'>"; // Add the category-specific class here
                        // Task Name
                    echo "<div class='task-column task-name'>";
                    echo "<h2>" . htmlspecialchars($row["task_name"]) . "</h2>";
                    echo "</div>";

                    // Description with icon
                    echo "<div class='task-column task-description'>";
                    echo "<i class='fas fa-align-left'></i>"; // Font Awesome icon for description
                    echo "<span>" . htmlspecialchars($row["description"]) . "</span>";
                    echo "</div>";

                    // Category with icon
                    echo "<div class='task-column task-category'>";
                    echo "<i class='fas fa-tags'></i>"; // Font Awesome icon for category
                    echo "<span>" . htmlspecialchars($row["category_name"]) . "</span>";
                    echo "</div>";

                    // Due Date with icon
                    echo "<div class='task-column task-due-date'>";
                    echo "<i class='fas fa-calendar-alt'></i>"; // Font Awesome icon for due date
                    echo "<span>" . htmlspecialchars($dueDate) . "</span>";
                    echo "</div>";

                    // Due Time with icon
                    echo "<div class='task-column task-due-time'>";
                    echo "<i class='fas fa-clock'></i>"; // Font Awesome icon for due time
                    echo "<span>" . htmlspecialchars($dueTime) . "</span>";
                    echo "</div>";

                    // Repeat Option with icon
                    echo "<div class='task-column task-status'>";
                    if($taskStatus=='pending'){
                    echo "<i class='fas fa-hourglass-half'></i>";}
                    elseif($taskStatus=='completed'){
                    echo "<i class='fas fa-check-circle'></i>";}
                    else {
                    echo "<i class='fas fa-exclamation-circle'></i>";}// Font Awesome icon for repeat option
                    echo "<span>" . htmlspecialchars($row["status"]) . "</span>";
                    echo "</div>";
                        echo "</div>";        
                    }
                } else {
                    echo "<p style='color: #ffffff;padding: 20px;'><strong>No tasks found.</strong></p>";
                }
        
        $stmt->close();
        $conn->close();
        
        ?>
    </div>
</div>