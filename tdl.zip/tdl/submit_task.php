<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Change as needed
$password = "";     // Change as needed
$dbname = "tdl";    // Use the existing database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$taskName = $_POST['taskName'];
$taskDescription = isset($_POST['taskDescription']) ? $_POST['taskDescription'] : '';
$dueDate = isset($_POST['dueDate']) ? $_POST['dueDate'] : NULL;
$dueTime = isset($_POST['dueTime']) ? $_POST['dueTime'] : NULL;
$repeatOption = isset($_POST['repeat']) ? $_POST['repeat'] : 'none';

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO tasks (task_name, description, due_date, due_time, repeat_option) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $taskName, $taskDescription, $dueDate, $dueTime, $repeatOption);

// Execute the statement
if ($stmt->execute()) {
    echo "New task added successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();

// Redirect to index page or another page
header("Location: index.php");
exit();
?>
