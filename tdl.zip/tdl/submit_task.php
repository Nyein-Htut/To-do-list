<?php
session_start();
date_default_timezone_set('Asia/Yangon');

// Check if user is logged in
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id']; // Assuming you store user_id in session on login

// Database connection parameters
$servername = "localhost";
$username = "root"; // Change as needed
$password = "";     // Change as needed
$dbname = "tdl";    // Use the existing database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the form inputs
$taskName = $_POST['taskName'];
$taskDescription = $_POST['taskDescription'];
$category = $_POST['category'];
$dueDate = !empty($_POST['dueDate']) ? $_POST['dueDate'] : date("Y-m-d");
$dueTime = !empty($_POST['dueTime']) ? $_POST['dueTime'] : '23:59:00';
echo "Received category: " . htmlspecialchars($category) . "<br>";
// Get category ID
if (!empty($category)) {
    $sql = "SELECT id FROM categories WHERE name = ? ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $categoryId = $row['id'];
    }
}


// Prepare and bind
$stmt = $conn->prepare("INSERT INTO tasks (user_id, task_name, description, category_id, due_date, due_time) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssss", $user_id, $taskName, $taskDescription, $categoryId, $dueDate, $dueTime);

// Execute the statement
if ($stmt->execute()) {
    // Redirect to the main page after successful submission
    header("Location: index.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
$updatePendingSql = "UPDATE tasks 
                             SET status = 'pending' 
                             WHERE due_date = '0000-00-00' 
                             OR CONCAT(due_date, ' ', due_time) > ? 
                             AND status != 'completed'
                            
                             AND user_id = ?";
        
        $stmt = $conn->prepare($updatePendingSql);
        $stmt->bind_param("si", $currentDateTime, $user_id);
        $stmt->execute();


/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tdl";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['login_user_id']; // Assuming you store user_id in session on login

// Retrieve form data
$taskId = isset($_POST['taskId']) ? (int)$_POST['taskId'] : 0;
$taskName = $_POST['taskName'];
$taskDescription = isset($_POST['taskDescription']) ? $_POST['taskDescription'] : null;
$categoryId = isset($_POST['category']) ? (int)$_POST['category'] : null;
$dueDate = isset($_POST['dueDate']) ? $_POST['dueDate'] : null;
$dueTime = isset($_POST['dueTime']) ? $_POST['dueTime'] : null;
$repeat = isset($_POST['repeat']) ? $_POST['repeat'] : null;

// If categoryId is not null, check if it exists
if ($categoryId !== null) {
    $categoryCheckSql = "SELECT COUNT(*) FROM categories WHERE id=?";
    $categoryCheckStmt = $conn->prepare($categoryCheckSql);
    $categoryCheckStmt->bind_param("i", $categoryId);
    $categoryCheckStmt->execute();
    $categoryCheckStmt->bind_result($categoryCount);
    $categoryCheckStmt->fetch();
    $categoryCheckStmt->close();

    if ($categoryCount == 0) {
        die("Error: The selected category does not exist.");
    }
}

// Insert or update task
if ($taskId) {
    // Update existing task
    $sql = "UPDATE tasks SET task_name=?, description=?, category_id=?, due_date=?, due_time=?, repeat_option=? WHERE id=? AND user_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssissiii", $taskName, $taskDescription, $categoryId, $dueDate, $dueTime, $repeat, $taskId, $user_id);
} else {
    // Insert new task
    $sql = "INSERT INTO tasks (task_name, description, category_id, due_date, due_time, repeat_option, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssissii", $taskName, $taskDescription, $categoryId, $dueDate, $dueTime, $repeat, $user_id);
}

if ($stmt->execute()) {
    header("Location: index.php"); // Redirect to your main page or task list
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();*/
?>



